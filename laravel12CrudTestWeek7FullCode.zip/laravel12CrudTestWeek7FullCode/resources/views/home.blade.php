@extends('layouts.backend')

@section('css_before')
@endsection

@section('header')
@endsection
 
@section('sidebarMenu')    
@endsection

@section('content')
@endsection

@section('footer')
@endsection

@section('js_before')
@endsection
