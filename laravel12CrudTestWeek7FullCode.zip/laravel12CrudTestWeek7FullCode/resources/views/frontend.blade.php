@extends('layouts.frontend')

@section('css_before')
@endsection

@section('navbar')
@endsection
 
 
@section('showProduct')    
@endsection

 

@section('footer')
@endsection

@section('js_before')
@endsection
