<?php  

protected $middlewareGroups = [
    'web' => [
        // ...
        \RealRashid\SweetAlert\ToSweetAlert::class,
    ],
    // ...
];
