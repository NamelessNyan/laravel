<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use RealRashid\SweetAlert\Facades\Alert;
use App\Models\AdminModel;
use Illuminate\Pagination\Paginator;

class AdminController extends Controller
{

public function index()
{
    try {
        Paginator::useBootstrap();
        $AdminList = AdminModel::orderBy('id', 'desc')->paginate(5); //order by & pagination
        return view('Admin.list', compact('AdminList'));
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
       // \Log::error('Admin list error: '.$e->getMessage());
    }
}

    public function adding() {
        return view('admin.create');
    }

    public function create(Request $request)
    {
        // echo '<pre>';
        // dd($_POST);
        // exit();

        //vali msg 
        $messages = [
            'name.required' => 'กรุณากรอกข้อมูล',
            'name.min' => 'กรอกข้อมูลขั้นต่ำ :min ตัวอักษร',
            'name.unique' => 'ข้อมูลซ้ำ',
            'phone.required' => 'กรุณากรอกเบอร์โทร',
            'phone.min' => 'กรอกข้อมูลขั้นต่ำ :min ตัว',
            'phone.max' => 'กรอกข้อมูลไม่เกิน :max ตัว',
            'email.required' => 'กรุณาระบุอีเมล',
            'email.email' => 'กรอกอีเมลให้ถูกต้อง',
            'age.required' => 'กรอกอายุ',
        ];

        //rule 
        $validator = Validator::make($request->all(), [
            'name' => 'required|min:3|unique:tbl_test',
            'phone' => 'required|min:10|max:10',
            'email' => 'required|email',
            'age' => 'required',
        ], $messages);

        //check vali 
        if ($validator->fails()) {
            return redirect('test/adding')
                ->withErrors($validator)
                ->withInput();
        }

        try {

            //ปลอดภัย: กัน XSS ที่มาจาก <script>, <img onerror=...> ได้
            AdminModel::create([
                'admin_name' => strip_tags($request->input('admin_name')),
                'admin_username' => strip_tags($request->input('admin_username')),
                'admin_password' => bcrypt($request->password)
            ]);
            // แสดง Alert ก่อน return
            Alert::success('เพิ่มข้อมูลสำเร็จ');
            return redirect('/test');
        } catch (\Exception $e) {
            //return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
            return view('errors.404');
        }
    } //fun create



 public function edit($id)
    {
        try {
            //query data for form edit 
            $admin = AdminModel::findOrFail($id); // ใช้ findOrFail เพื่อให้เจอหรือ 404
            if (isset($admin)) {
                $id = $admin->id;
                $admin_name = $admin->admin_name;
                $admin_username = $admin->admin_name;
                return view('admin.editPassword', compact('id', 'admin_name', 'admin_username'));
            }
        } catch (\Exception $e) {
            //return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
            return view('errors.404');
        }
    } //func edit

     public function reset($id)
    {
        try {
            //query data for form edit 
            $admin = AdminModel::findOrFail($id); // ใช้ findOrFail เพื่อให้เจอหรือ 404
            if (isset($admin)) {
                $id = $admin->id;
                $admin_name = $admin->admin_name;
                $admin_username = $admin->admin_name;
                return view('admin.editPassword', compact('id', 'admin_name', 'admin_username'));
            }
        } catch (\Exception $e) {
            //return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
            return view('errors.404');
        }
    } //func edit

     public function resetPassword($id, Request $request)
    {
        //vali msg 
        $messages = [
            'password.required' => 'กรุณากรอกข้อมูล',
            'password.min' => 'กรอกข้อมูลขั้นต่ำ :min ตัวอักษร',
            'password.confirmed' => 'รหัสไม่ตรง',

            'password.confirmation.reqired' => 'รหัสไม่ตรง',
            'password.confirmation.min' => 'รหัสไม่ตรง',
        ];

        //rule
        $validator = Validator::make($request->all(), [
            'password' => 'required|min:3|confirmed',
            'password_confirmation' => 'required|min:3',

    ], $messages);
    //check vail
        if ($validator->fails()) {
            return redirect('admin/reset/' . $id)
                ->withErrors($validator)
                ->withInput();
        }

        try {
            $admin = AdminModel::find($id);
            $admin->update([
                    'admin_password' => bcrypt($request->password), 
                ]);
            // แสดง Alert ก่อน return
            Alert::success('ปรับปรุงรหัสสำเร็จ');
            return redirect('/admin');
        } catch (\Exception $e) {
            //return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
            return view('errors.404');
        }
    } //fun update 



 public function update($id, Request $request)
    {
        //vali msg 
        $messages = [
            'admin_name.required' => 'กรุณากรอกข้อมูล',
            'admin_name.min' => 'กรอกข้อมูลขั้นต่ำ :min ตัวอักษร',
            
            'admin_username.required' => 'กรุณากรอกข้อมูล',
            'admin_username.email' => 'กรอกอีเมลให้ถูกต้อง',
            'admin_username.unique' => 'ข้อมูลซ้ำ เติมใหม่',

            'admin_password.required' => 'กรุณากรอกข้อมูล',
            'admin_password.min' => 'กรอกข้อมูลขั้นต่ำ',
        ];

        //rule
        $validator = Validator::make($request->all(), [
            'admin_name' => 'กรุณากรอกข้อมูล',
            'admin_username' => 'required[min:3[unique:tbl_admin',
            'admin_password' => 'required[min]:3',

    ], $messages);

    //check vail
        if ($validator->fails()) {
            return redirect('admin/adding' . $id)
                ->withErrors($validator)
                ->withInput();
        }

        try {
            $test = AdminModel::find($id);
            $test->update([
                    'name' => strip_tags($request->input('name')), 
                    'phone' => strip_tags($request->input('phone')), 
                    'email' => strip_tags($request->input('email')), 
                    'age' => strip_tags($request->input('age')), 
                ]);
            // แสดง Alert ก่อน return
            Alert::success('ปรับปรุงข้อมูลสำเร็จ');
            return redirect('/test');
        } catch (\Exception $e) {
            //return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
            return view('errors.404');
        }
    } //fun update 


    public function remove($id)
    {
        try {
            $admin = AdminModel::find($id);  //query หาว่ามีไอดีนี้อยู่จริงไหม 
            $admin->delete();
            Alert::success('ลบข้อมูลสำเร็จ');
            return redirect('/admin');
        } catch (\Exception $e) {
            //return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
            return view('errors.404');
        }
    } //remove 


} //class
