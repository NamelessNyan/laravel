<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebarMenu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h3> ::Member Managements ::
        <a href="/member/adding" class="btn btn-primary btn-sm"> Add member </a>
    </h3>

    <table class="table table-bordered table-striped table-hover">
        <thead>
            <tr class="table-info">
                <th width="5%" class="text-center">No.</th>
                <th width="5%">Pic</th>
                <th width="20%">Name</th>
                <th width="20%">Email</th>
                <th width="10%">Phone</th>
                <th width="5%" class="text-center">reset</th>
                <th width="5%" class="text-center">edit</th>
                <th width="5%" class="text-center">delete</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align="center"><?php echo e($row->member_id); ?></td>
                <td><img src="<?php echo e(asset('storage/' . $row->member_img)); ?>" width="100"></td>
                <td> <?php echo e($row->member_name); ?> </td>
                <td> <?php echo e($row->member_username); ?> </td>
                <td> <?php echo e($row->member_phone); ?> </td>
                <td align="center">
                     <a href="/member/reset/<?php echo e($row->member_id); ?>" class="btn btn-info btn-sm">reset</a>
                </td>
                <td align="center">
                    <a href="/member/<?php echo e($row->member_id); ?>" class="btn btn-warning btn-sm">edit</a>
                </td>
                <td align="center">

                    <button type="button" class="btn btn-danger btn-sm" onclick="deleteConfirm(<?php echo e($row->member_id); ?>)">delete</button>
                        <form id="delete-form-<?php echo e($row->member_id); ?>" action="/member/remove/<?php echo e($row->member_id); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                        </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div>
        <?php echo e($members->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>




<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
function deleteConfirm(id) {
    Swal.fire({
        title: 'แน่ใจหรือไม่?',
        text: "คุณต้องการลบข้อมูลนี้จริง ๆ หรือไม่",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'ใช่, ลบเลย!',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            // ถ้ากด "ลบเลย" ให้ submit form ที่ซ่อนไว้
            document.getElementById('delete-form-' + id).submit();
        }
    })
}
</script>


<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/member/list.blade.php ENDPATH**/ ?>