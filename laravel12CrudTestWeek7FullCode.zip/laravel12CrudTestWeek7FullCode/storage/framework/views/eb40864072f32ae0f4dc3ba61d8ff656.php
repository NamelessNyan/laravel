<?php $__env->startSection('css_before'); ?>
<?php $__env->startSection('navbar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('showProduct'); ?>


<div class="container mt-4">
    <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-6">

            <h3> :: form Login :: </h3>


            <form action="/login" method="post">
                <?php echo csrf_field(); ?>



                <div class="form-group row mb-2">
                    
                    <div class="col-sm-7">
                        <input type="email" class="form-control" name="username" required placeholder="email/username"
                            minlength="3" value="<?php echo e(old('username')); ?>">
                        <?php if(isset($errors)): ?>
                        <?php if($errors->has('username')): ?>
                        <div class="text-danger"> <?php echo e($errors->first('username')); ?></div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row mb-2">
                    
                    <div class="col-sm-7">
                        <input type="password" class="form-control" name="password" required placeholder="Password"
                            minlength="3">
                        <?php if(isset($errors)): ?>
                        <?php if($errors->has('password')): ?>
                        <div class="text-danger"> <?php echo e($errors->first('password')); ?></div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

               
 

                <div class="form-group row mb-2">
                    
                    <div class="col-sm-5">

                        <button type="submit" class="btn btn-primary"> Login </button>
                        <a href="/" class="btn btn-danger">cancel</a>
                    </div>
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontendAuth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/auth/login.blade.php ENDPATH**/ ?>