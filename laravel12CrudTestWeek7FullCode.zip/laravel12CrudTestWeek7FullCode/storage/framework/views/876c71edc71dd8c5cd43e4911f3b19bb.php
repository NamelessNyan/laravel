<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebarMenu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h3> ::Product Managements ::
        <a href="/product/adding" class="btn btn-primary btn-sm"> Add Product </a>
    </h3>

    <table class="table table-bordered table-striped table-hover">
        <thead>
            <tr class="table-info">
                <th width="5%" class="text-center">No.</th>
                <th width="5%">Pic</th>
                <th width="65%">Product Name & Detail </th>
                <th width="15%" class="text-center">Price</th>
                <th width="5%" class="text-center">edit</th>
                <th width="5%" class="text-center">delete</th>
            </tr>
        </thead>

        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td align="center"><?php echo e($row->id); ?></td>
                <td>
                    
                    <img src="<?php echo e(asset('storage/' . $row->product_img)); ?>" width="100"></td>
                <td>
                    <b>Name: <?php echo e($row->product_name); ?></b> <br>
                    Detail: 
                    <?php echo e(Str::limit($row->product_detail, 120, '...')); ?>

                </td>
                <td align="right">฿<?php echo e(number_format($row->product_price, 2)); ?></td>
                <td align="center">
                    <a href="/product/<?php echo e($row->id); ?>" class="btn btn-warning btn-sm">edit</a>
                </td>
                <td align="center">

                    

                    
                    <button type="button" class="btn btn-danger btn-sm" onclick="deleteConfirm(<?php echo e($row->id); ?>)">delete</button>

                        <form id="delete-form-<?php echo e($row->id); ?>" action="/product/remove/<?php echo e($row->id); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                        </form>


                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div>
        <?php echo e($products->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>




<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
function deleteConfirm(id) {
    Swal.fire({
        title: 'แน่ใจหรือไม่?',
        text: "คุณต้องการลบข้อมูลนี้จริง ๆ หรือไม่",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'ใช่, ลบเลย!',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            // ถ้ากด "ลบเลย" ให้ submit form ที่ซ่อนไว้
            document.getElementById('delete-form-' + id).submit();
        }
    })
}
</script>


<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/products/list.blade.php ENDPATH**/ ?>