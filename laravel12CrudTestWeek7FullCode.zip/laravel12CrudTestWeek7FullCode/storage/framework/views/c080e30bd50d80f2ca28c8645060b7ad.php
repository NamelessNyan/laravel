<?php $__env->startSection('js_before'); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebarMenu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

 <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


<h3>:: Dashboard </h3>

<div class="row">
    <div class="col-sm-3 col-md-3">
        <div class="alert alert-success" role="alert">
            <h5> Sales <br> <?php echo e(number_format($SumPrice)); ?> THB. </h5>
        </div>
    </div>

    <div class="col-sm-3 col-md-3">
        <div class="alert alert-danger" role="alert">
            <h5> Products <br> <?php echo e($CountPrd); ?> Sku. </h5>
        </div>
    </div>





    <div class="col-sm-3 col-md-3">
        <div class="alert alert-primary" role="alert">

            <h5> Admins <br> <?php echo e($CountAdmin); ?> List. </h5>

        </div>
    </div>


    <div class="col-sm-3 col-md-3">
        <div class="alert alert-info" role="alert">
            <h5> View <br>
                <?php echo e(number_format($CountView)); ?> views </h5>
        </div>
    </div>

</div>


<div class="row mt-3">
    <div class="col-sm-12">
       <h5>จำนวนผู้เข้าชมเว็บไซต์ (12 เดือนล่าสุด)</h5>

    <canvas id="visitsChart" width="600" height="300"></canvas>

    <script>
        const ctx = document.getElementById('visitsChart').getContext('2d');

        const visitsChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?php echo json_encode($labels); ?>, // ['มกราคม-2025', 'กุมภาพันธ์-2025', ...]
                datasets: [{
                    label: 'จำนวนเข้าชมเว็บไซต์ล่าสุด 12 เดือน',
                    data: <?php echo json_encode($data); ?>, // [123, 456, ...]
                   // borderColor: 'rgba(75, 192, 192, 1)',
                    backgroundColor: 'rgba(247, 156, 183)',
                    tension: 0.3,
                    fill: true,
                    pointRadius: 5,
                    pointHoverRadius: 7
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/dashboard/index.blade.php ENDPATH**/ ?>