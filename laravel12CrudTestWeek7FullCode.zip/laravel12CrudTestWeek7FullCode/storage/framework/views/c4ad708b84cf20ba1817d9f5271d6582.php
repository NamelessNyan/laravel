<?php $__env->startSection('css_before'); ?>
<?php $__env->startSection('navbar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('showProduct'); ?>

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-12 col-sm-4 col-md-4 col-lg-3 mb-2">
      <div class="card" style="width: 100%;">
        <a href="/detail/<?php echo e($data->id); ?>">
          <img src="<?php echo e(asset('storage/' . $data->product_img)); ?>" class="card-img-top" alt="devbanban.com">
        </a>
        <div class="card-body">
          <h5 class="card-title">
            <a href="/detail/<?php echo e($data->id); ?>" class="link-offset-2 link-underline link-underline-opacity-0">
              <?php echo e($data->product_name); ?>

            </a>
          </h5>
          <p class="card-text">Price <?php echo e(number_format($data->product_price)); ?> THB.</p>
          <a href="/detail/<?php echo e($data->id); ?>" class="btn btn-success">more detail click...</a>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  <div class="row mt-2 mb-2">
    <!-- Pagination links -->
    <div class="col-sm-5 col-md-5"></div>
    <div class="col-sm-3 col-md-3">
      <center>
        <?php echo e($products->links()); ?>

      </center>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/home/product_index.blade.php ENDPATH**/ ?>