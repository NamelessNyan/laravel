<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebarMenu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="row">
        <div class="col-sm-12">

            <h3> :: form Update Password :: </h3>


            <form action="/admin/reset/<?php echo e($id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="form-group row mb-2">
                    <label class="col-sm-2"> name </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="name" disabled placeholder="name"
                            value="<?php echo e($name); ?>">

                    </div>
                </div>

                <div class="form-group row mb-2">
                    <label class="col-sm-2"> Email/Username </label>
                    <div class="col-sm-6">
                        <input type="email" class="form-control" name="username" disabled placeholder="email"
                            value="<?php echo e($username); ?>" minlength="3">
                    </div>
                </div>

                <div class="form-group row mb-2">
                    <label class="col-sm-2"> New Password </label>
                    <div class="col-sm-6">
                        <input type="password" class="form-control" name="password" required
                            placeholder="New Password 3 characters">
                        <?php if(isset($errors)): ?>
                        <?php if($errors->has('password')): ?>
                        <div class="text-danger"> <?php echo e($errors->first('password')); ?></div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="form-group row mb-2">
                    <label class="col-sm-2"> Confirm Password </label>
                    <div class="col-sm-6">
                        <input type="password" class="form-control" name="password_confirmation" required
                            placeholder="Confirm Password 3characters" min="3">
                        <?php if(isset($errors)): ?>
                        <?php if($errors->has('password_confirmation')): ?>
                        <div class="text-danger"> <?php echo e($errors->first('password_confirmation')); ?></div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="form-group row mb-2">
                    <label class="col-sm-2"> </label>
                    <div class="col-sm-6">
                        <button type="submit" class="btn btn-primary"> Update </button>
                        <a href="/admin" class="btn btn-danger">cancel</a>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/admins/editPassword.blade.php ENDPATH**/ ?>