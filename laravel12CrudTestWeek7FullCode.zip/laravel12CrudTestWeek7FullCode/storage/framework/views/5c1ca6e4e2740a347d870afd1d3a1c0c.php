<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<?php $__env->stopSection(); ?>
 
 
<?php $__env->startSection('showProduct'); ?>    
<?php $__env->stopSection(); ?>

 

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontendAuth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/frontendAuth.blade.php ENDPATH**/ ?>