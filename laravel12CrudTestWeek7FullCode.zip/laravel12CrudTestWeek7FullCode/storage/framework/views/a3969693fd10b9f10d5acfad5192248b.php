<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebarMenu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="container mt-4">
    <div class="row">
        <div class="col-sm-9">

            <h3> :: form Add Admin :: </h3>


            <form action="/admin/" method="post">
                <?php echo csrf_field(); ?>

                 <div class="form-group row mb-2">
                    <label class="col-sm-2"> User Role </label>
                    <div class="col-sm-6">
                        <select name="user_role" required class="form-control">
                            <option value="">-- เลือกข้อมูล --</option>
                            <option value="admin">-- admin --</option>
                            <option value="member">-- member --</option>
                        </select>
                        <?php if(isset($errors)): ?>
                        <?php if($errors->has('user_role')): ?>
                        <div class="text-danger"> <?php echo e($errors->first('user_role')); ?></div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>



                <div class="form-group row mb-2">
                    <label class="col-sm-2"> Username </label>
                    <div class="col-sm-6">
                        <input type="email" class="form-control" name="username" required placeholder="email/username"
                            minlength="3"  value="<?php echo e(old('username')); ?>">
                        <?php if(isset($errors)): ?>
                        <?php if($errors->has('username')): ?>
                        <div class="text-danger"> <?php echo e($errors->first('username')); ?></div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row mb-2">
                    <label class="col-sm-2"> Password </label>
                    <div class="col-sm-6">
                        <input type="password" class="form-control" name="password" required placeholder="Password"
                            minlength="3">
                        <?php if(isset($errors)): ?>
                        <?php if($errors->has('password')): ?>
                        <div class="text-danger"> <?php echo e($errors->first('password')); ?></div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row mb-2">
                    <label class="col-sm-2">Name </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" name="name" required placeholder="admin name"
                            minlength="3" value="<?php echo e(old('name')); ?>">
                        <?php if(isset($errors)): ?>
                        <?php if($errors->has('name')): ?>
                        <div class="text-danger"> <?php echo e($errors->first('name')); ?></div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="form-group row mb-2">
                    <label class="col-sm-2"> Phone </label>
                    <div class="col-sm-6">
                        <input type="tel" class="form-control" name="phone" required placeholder="Phone 10 digit"
                            minlength="3" maxlength="10" value="<?php echo e(old('phone')); ?>">
                        <?php if(isset($errors)): ?>
                        <?php if($errors->has('phone')): ?>
                        <div class="text-danger"> <?php echo e($errors->first('phone')); ?></div>
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="form-group row mb-2">
                    <label class="col-sm-2"> </label>
                    <div class="col-sm-5">

                        <button type="submit" class="btn btn-primary"> Save </button>
                        <a href="/admin" class="btn btn-danger">cancel</a>
                    </div>
                </div>

            </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/admins/create.blade.php ENDPATH**/ ?>