<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebarMenu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="row">
    <div class="col-md-10">
<h3> Test Data  
<a  href="/test/adding" class="btn btn-primary btn-sm mb-2"> + Data </a>
</h3>


<table class="table table-bordered table-striped table-hover">
    <thead>
        <tr class="table-info">
            <th width="5%" class="text-center">ลำดับ</th>
            <th width="30%">ชื่อ - สกุล</th>
            <th width="10%">เบอร์โทร</th>
            <th width="20%">อีเมล</th>
            <th width="5%">อายุ</th>
            <th width="5%">แก้ไข</th>
            <th width="5%">ลบ</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $testList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td align="center"> <?php echo e($loop->iteration); ?>.  <!--เรียงลำดับใหม่  --></td>
            <td><?php echo e($row->name); ?>  </td>
            <td><?php echo e($row->phone); ?>  </td>
            <td><?php echo e($row->email); ?>  </td>
            <td align="center"><?php echo e($row->age); ?>  </td>
            <td>
                    <a href="/test/<?php echo e($row->id); ?>" class="btn btn-warning btn-sm">edit</a>
            </td>
            <td>
                
                 <button type="button" class="btn btn-danger btn-sm" onclick="deleteConfirm(<?php echo e($row->id); ?>)">delete</button>

                        <form id="delete-form-<?php echo e($row->id); ?>" action="/test/remove/<?php echo e($row->id); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                        </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>

<p> Add column phone, email, age </p>

<div>
        <?php echo e($testList->links()); ?>

    </div>
    
</div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
function deleteConfirm(id) {
    Swal.fire({
        title: 'ยืนยันการลบข้อมูล',
        text: "หากลบแล้วจะไม่สามารถกู้คืนได้!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'ใช่, ลบเลย!',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('delete-form-' + id).submit();
        }
    });
}
</script>




<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel12CrudTest\resources\views/test/list.blade.php ENDPATH**/ ?>