<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel 12 Basic CRUD by devbanban.com 2025</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    <?php echo $__env->yieldContent('css_before'); ?>
  </head>
  <body>

    <div class="container">
      <div class="row">
          <div class="col">
              <div class="alert alert-success text-center" role="alert">
                <h4>Back Office || Laravel 12 || ยินดีต้อนรับคุณ Admin</h4>
              </div>
          </div>
      </div>
    </div>

    <?php echo $__env->yieldContent('header'); ?>

    <div class="container">
      <div class="row">

        <div class="col-md-3">
          <div class="list-group">
            <a href="/" class="list-group-item list-group-item-action active" aria-current="true">
              Home
            </a>
          
            <a href="/test" class="list-group-item list-group-item-action"> - TestCRUD </a>
           
             

 
          
          </div>
          <?php echo $__env->yieldContent('sidebarMenu'); ?>
        </div>

        <div class="col-md-9">
          <?php echo $__env->yieldContent('content'); ?>
        </div>

      </div>
    </div>

    <footer class="mt-5 mb-2">
      <p class="text-center">by devbanban.com @2025</p>
    </footer>
    
    <?php echo $__env->yieldContent('footer'); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>

    <?php echo $__env->yieldContent('js_before'); ?>

    

    
    <?php echo $__env->make('sweetalert::alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  </body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12CrudTest/resources/views/layouts/backend.blade.php ENDPATH**/ ?>