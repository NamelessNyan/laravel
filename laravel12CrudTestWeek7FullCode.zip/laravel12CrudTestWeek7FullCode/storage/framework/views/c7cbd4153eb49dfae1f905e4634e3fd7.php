<?php $__env->startSection('css_before'); ?>
<?php $__env->startSection('navbar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('showProduct'); ?>

<div class="col-12 col-sm-3 col-md-3 mb-2">
    <div class="card" style="width: 100%;">
        <img src="<?php echo e(asset('storage/' . $product_img)); ?>" class="card-img-top" alt="devbanban.com">
    </div>
</div>
<div class="col-12 col-sm-8 col-md-8 mb-2">
    <h5 class="card-title"><?php echo e($product_name); ?>, Price <?php echo e(number_format($product_price)); ?> THB. </h5>
    <p>
        product detail
        <br>
        <?php echo e($product_detail); ?>

    </p>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/home/product_detail.blade.php ENDPATH**/ ?>