<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebarMenu'); ?>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 


    <h3> :: Form Add Product :: </h3>

    <form action="/product/" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group row mb-2">
            <label class="col-sm-2"> Product Name </label>
            <div class="col-sm-7">
                <input type="text" class="form-control" name="product_name" required placeholder="Product Name "
                    minlength="3" value="<?php echo e(old('product_name')); ?>">
                <?php if(isset($errors)): ?>
                <?php if($errors->has('product_name')): ?>
                <div class="text-danger"> <?php echo e($errors->first('product_name')); ?></div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row mb-2">
            <label class="col-sm-2"> Product detail </label>
            <div class="col-sm-7">
                <textarea name="product_detail" class="form-control" rows="4" required
                    placeholder="Product detail "><?php echo e(old('product_detail')); ?></textarea>
                <?php if(isset($errors)): ?>
                <?php if($errors->has('product_detail')): ?>
                <div class="text-danger"> <?php echo e($errors->first('product_detail')); ?></div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row mb-2">
            <label class="col-sm-2">Price </label>
            <div class="col-sm-6">
                <input type="number" class="form-control" name="product_price" required placeholder="product_price"
                    min="0" value="<?php echo e(old('product_price')); ?>">
                <?php if(isset($errors)): ?>
                <?php if($errors->has('product_price')): ?>
                <div class="text-danger"> <?php echo e($errors->first('product_price')); ?></div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row mb-2">
            <label class="col-sm-2"> Pic </label>
            <div class="col-sm-6">
                <input type="file" name="product_img" required placeholder="product_img" accept="image/*">
                <?php if(isset($errors)): ?>
                <?php if($errors->has('product_img')): ?>
                <div class="text-danger"> <?php echo e($errors->first('product_img')); ?></div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row mb-2">
            <label class="col-sm-2"> </label>
            <div class="col-sm-5">

                <button type="submit" class="btn btn-primary"> Insert Product </button>
                <a href="/product" class="btn btn-danger">cancel</a>
            </div>
        </div>

    </form>

</div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/products/create.blade.php ENDPATH**/ ?>