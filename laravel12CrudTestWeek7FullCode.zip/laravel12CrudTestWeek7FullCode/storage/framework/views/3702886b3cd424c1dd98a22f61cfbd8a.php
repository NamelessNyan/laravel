<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebarMenu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container mt-4">
    <div class="row">
    <div class="col-md-12">
<h1>Admin data 
<a  href="/admin/adding" class="btn btn-primary btn-sm mb-2"> + Admin </a>
</h1>

<table class="table table-bordered table-striped table-hover">
    <thead>
        <tr class="table-info">
            <th width="5%" class="text-center">No.</th>
            <th width="30%">Admin Name</th>
            <th width="20%">Email/Username</th>
            <th width="10%">Phone</th>
            <th width="15%">Role</th>
            <th width="5%">edit</th>
            <th width="5%">PWD</th>
             <th width="5%">delete</th>
        </tr>
    </thead>

    <tbody>
         
        <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td align="center"> <?php echo e($loop->iteration); ?>. </td>
            <td><?php echo e($row->name); ?> </td>
            <td><?php echo e($row->username); ?> </td>
            <td><?php echo e($row->phone); ?> </td>
            <td><?php echo e($row->user_role); ?> </td>
            <td>
                    <a href="/admin/<?php echo e($row->id); ?>" class="btn btn-warning btn-sm">edit</a>
            </td>
            
            <td>
                <a href="/admin/reset/<?php echo e($row->id); ?>" class="btn btn-info btn-sm">reset</a>
        </td>
        <td>
                

                        <button type="button" class="btn btn-danger btn-sm" onclick="deleteConfirm(<?php echo e($row->id); ?>)">delete</button>
                        <form id="delete-form-<?php echo e($row->id); ?>" action="/admin/remove/<?php echo e($row->id); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                        </form>


            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>

 <div>
        <?php echo e($admins->links()); ?>

    </div>
    
</div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
function deleteConfirm(id) {
    Swal.fire({
        title: 'คุณแน่ใจหรือไม่?',
        text: "หากลบแล้วจะไม่สามารถกู้คืนได้!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'ใช่, ลบเลย!',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('delete-form-' + id).submit();
        }
    });
}
</script>
<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/admins/list.blade.php ENDPATH**/ ?>