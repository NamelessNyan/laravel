<?php $__env->startSection('js_before'); ?>
<?php echo $__env->make('sweetalert::alert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->startSection('sidebarMenu'); ?>   
<?php $__env->startSection('content'); ?>

    <h3> :: form Update member :: </h3>

    <form action="/member/<?php echo e($member_id); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <div class="form-group row mb-2">
        <label class="col-sm-2"> Username/Email </label>
        <div class="col-sm-6">
            <input type="email" class="form-control" name="member_username" required placeholder="Username/Email"
                minlength="3" value="<?php echo e($member_username); ?>">
            <?php if(isset($errors)): ?>
            <?php if($errors->has('member_username')): ?>
            <div class="text-danger"> <?php echo e($errors->first('member_username')); ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

        <div class="form-group row mb-2">
            <label class="col-sm-2"> Name </label>
            <div class="col-sm-7">
                <input type="text" class="form-control" name="member_name" required placeholder="member Name "
                    minlength="3" value="<?php echo e($member_name); ?>">
                <?php if(isset($errors)): ?>
                <?php if($errors->has('member_name')): ?>
                <div class="text-danger"> <?php echo e($errors->first('member_name')); ?></div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>


    <div class="form-group row mb-2">
        <label class="col-sm-2"> Phone </label>
        <div class="col-sm-6">
            <input type="tel" class="form-control" name="member_phone" required placeholder="Phone 10 digit" minlength="3"
                maxlength="10" value="<?php echo e($member_phone); ?>">
            <?php if(isset($errors)): ?>
            <?php if($errors->has('member_phone')): ?>
            <div class="text-danger"> <?php echo e($errors->first('member_phone')); ?></div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

        

        <div class="form-group row mb-2">
            <label class="col-sm-2"> Pic </label>
            <div class="col-sm-6">
                old img <br>
                <img src="<?php echo e(asset('storage/' . $member_img)); ?>" width="200px"> <br>
                choose new image <br>
                <input type="file" name="member_img" placeholder="member_img" accept="image/*">
                <?php if(isset($errors)): ?>
                <?php if($errors->has('member_img')): ?>
                <div class="text-danger"> <?php echo e($errors->first('member_img')); ?></div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row mb-2">
            <label class="col-sm-2"> </label>
            <div class="col-sm-5">
                <input type="hidden" name="oldImg" value="<?php echo e($member_img); ?>">
                <button type="submit" class="btn btn-primary"> Update </button>
                <a href="/member" class="btn btn-danger">cancel</a>
            </div>
        </div>

    </form>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/laravel12ProductManagement2025/resources/views/member/edit.blade.php ENDPATH**/ ?>