<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\TestController;
use App\Http\Controllers\StaffController;
use App\Http\Controllers\GundamController;
use App\Http\Controllers\FactionController;
use App\Http\Controllers\SeriesController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\DB;

//dashboard
Route::get('/dashboard',  [DashboardController::class, 'index']);

//login เสร็จไปหน้า Dashboard
Route::middleware('auth:staff')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
});

//authentication
Route::get('/login',  [AuthController::class, 'index'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
//ทำไมต้องมี name('login') ?
//เวลาใช้ auth middleware ถ้า user ยังไม่ login → Laravel จะ redirect ไปหา route ที่ชื่อว่า login โดยอัตโนมัติ
//ถ้าไม่เจอ → มันก็โยน error Route [login] not defined.

//home page
Route::get('/', [HomeController::class, 'index']);

//product home view
Route::get('/detail/{id}',  [HomeController::class, 'detail']);
Route::get('/search',  [HomeController::class, 'searchGundam']);



//staff crud
Route::middleware('auth:staff')->group(function () {
  Route::get('/staff',                [StaffController::class, 'index'])->name('staff.index');
  Route::get('/staff/adding',         [StaffController::class, 'adding'])->name('staff.add');
  Route::post('/staff',               [StaffController::class, 'create'])->name('staff.store');

  // วาง 2 เส้นนี้ "ก่อน" /staff/{id}
  Route::get('/staff/reset/{id}',     [StaffController::class, 'reset'])->name('staff.reset');
  Route::put('/staff/reset/{id}',     [StaffController::class, 'resetPassword'])->name('staff.resetPassword');

  Route::get('/staff/{id}',           [StaffController::class, 'edit'])->name('staff.edit');
  Route::put('/staff/{id}',           [StaffController::class, 'update'])->name('staff.update');
  Route::delete('/staff/remove/{id}', [StaffController::class, 'remove'])->name('staff.remove');
});

//test crud
Route::get('/test', [TestController::class, 'index']);
Route::get('/test/adding',  [TestController::class, 'adding']);
Route::post('/test',  [TestController::class, 'create']);
Route::get('/test/{id}',  [TestController::class, 'edit']);
Route::put('/test/{id}',  [TestController::class, 'update']);
Route::delete('/test/remove/{id}',  [TestController::class, 'remove']);


//gundam crud
Route::middleware('auth:staff')->prefix('gundam')->name('gundam.')->group(function () {
  Route::get('/',            [GundamController::class, 'index'])->name('index');
  Route::get('/adding',      [GundamController::class, 'adding'])->name('add');
  Route::post('/',           [GundamController::class, 'create'])->name('store');
  Route::get('/{id}',        [GundamController::class, 'edit'])->name('edit')->whereNumber('id');
  Route::put('/{id}',        [GundamController::class, 'update'])->name('update')->whereNumber('id');
  Route::delete('/remove/{id}', [GundamController::class, 'remove'])->name('remove')->whereNumber('id');
});

// faction crud
Route::get('/faction',         [FactionController::class, 'index'])->name('faction.index');
Route::get('/faction/adding',  [FactionController::class, 'adding'])->name('faction.adding');
Route::post('/faction',        [FactionController::class, 'create'])->name('faction.store');
Route::get('/faction/{id}',    [FactionController::class, 'edit'])->name('faction.edit');
Route::put('/faction/{id}',    [FactionController::class, 'update'])->name('faction.update');
Route::delete('/faction/remove/{id}', [FactionController::class, 'remove'])->name('faction.remove');


// series crud
Route::get('/series',                [SeriesController::class, 'index'])->name('series.index');
Route::get('/series/adding',         [SeriesController::class, 'adding'])->name('series.adding');
Route::post('/series',               [SeriesController::class, 'create'])->name('series.store');
Route::get('/series/{id}',           [SeriesController::class, 'edit'])->name('series.edit');
Route::put('/series/{id}',           [SeriesController::class, 'update'])->name('series.update');
Route::delete('/series/remove/{id}', [SeriesController::class, 'remove'])->name('series.remove');

// login
Route::get('/login',  [AuthController::class, 'index'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/debug/counter', function () {
    try {
        $exists = DB::select('SHOW TABLES LIKE "tbl_counter"');
        if (!$exists) return 'tbl_counter: NOT FOUND';
        $count = DB::table('tbl_counter')->count();
        return "tbl_counter exists. rows = {$count}";
    } catch (\Throwable $e) {
        return 'Error: ' . $e->getMessage();
    }
});
