-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2025 at 06:40 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel12`
--
CREATE DATABASE IF NOT EXISTS `laravel12` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `laravel12`;

-- Table structure for table `tbl_admin`
CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(200) NOT NULL,
  `admin_username` varchar(200) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `dateCreate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `tbl_faction`
CREATE TABLE `tbl_faction` (
  `faction_id` int(11) NOT NULL AUTO_INCREMENT,
  `faction_name` varchar(200) NOT NULL,
  `dateCreate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`faction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `tbl_series`
CREATE TABLE `tbl_series` (
  `series_id` int(11) NOT NULL AUTO_INCREMENT,
  `series_name` varchar(200) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `dateCreate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`series_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table structure for table `tbl_gundam`
CREATE TABLE `tbl_gundam` (
  `gundam_id` int(11) NOT NULL AUTO_INCREMENT,
  `gundam_name` varchar(200) NOT NULL,
  `gundam_model_no` varchar(100) NOT NULL,
  `faction_id` int(11) NOT NULL,
  `series_id` int(11) NOT NULL,
  `height_m` decimal(5,2) DEFAULT NULL,
  `weight_kg` decimal(5,2) DEFAULT NULL,
  `gundam_image_url` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `dateCreate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`gundam_id`),
  KEY `fk_faction` (`faction_id`),
  KEY `fk_series` (`series_id`),
  CONSTRAINT `fk_faction` FOREIGN KEY (`faction_id`) REFERENCES `tbl_faction` (`faction_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_series` FOREIGN KEY (`series_id`) REFERENCES `tbl_series` (`series_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_test`
--

CREATE TABLE `tbl_test` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_test`
--

INSERT INTO `tbl_test` (`id`, `name`, `email`, `phone`) VALUES
(1, '222', '22@fdfdf', '2223434343'),
(2, '111', 'ss@g.com', '1111232324');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_username` (`admin_username`);

--
-- Indexes for table `tbl_faction`
ALTER TABLE `tbl_faction`
  ADD PRIMARY KEY (`faction_id`),
  ADD UNIQUE KEY `faction_name` (`faction_name`);

-- Indexes for table `tbl_series`
ALTER TABLE `tbl_series`
  ADD PRIMARY KEY (`series_id`),
  ADD UNIQUE KEY `series_name` (`series_name`);

-- Indexes for table `tbl_gundam`
ALTER TABLE `tbl_gundam`
  ADD PRIMARY KEY (`gundam_id`),
  ADD KEY `fk_faction` (`faction_id`),
  ADD KEY `fk_series` (`series_id`);

--
-- Indexes for table `tbl_test`
--
ALTER TABLE `tbl_test`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_gundam`
--
ALTER TABLE `tbl_gundam`
  MODIFY `gundam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_series`
--
ALTER TABLE `tbl_series`
  MODIFY `series_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

-- AUTO_INCREMENT for table `tbl_faction`
--
ALTER TABLE `tbl_faction`
  MODIFY `faction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_test`
--
ALTER TABLE `tbl_test`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
