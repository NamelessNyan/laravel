<?php $__env->startSection('content'); ?>
<h1>staff data
  <a href="<?php echo e(route('staff.add')); ?>" class="btn btn-primary btn-sm mb-2">+ staff</a>
</h1>

<table class="table table-bordered table-striped table-hover">
  <thead>
    <tr class="table-info">
      <th width="5%" class="text-center">No.</th>
      <th width="30%">staff Name</th>
      <th width="20%">Email/Username</th>
      <th width="5%" class="text-center">edit</th>
      <th width="5%" class="text-center">PWD</th>
      <th width="5%" class="text-center">delete</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $staffList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $no = ($staffList->currentPage()-1)*$staffList->perPage() + $loop->iteration; ?>
    <tr>
      <td class="text-center"><?php echo e($no); ?>.</td>
      <td><?php echo e($row->staff_name); ?></td>
      <td><?php echo e($row->staff_username); ?></td>
      <td class="text-center">
        <a href="<?php echo e(route('staff.edit', $row->staff_id)); ?>" class="btn btn-warning btn-sm">edit</a>
      </td>
      <td class="text-center">
        <a href="<?php echo e(route('staff.reset', $row->staff_id)); ?>" class="btn btn-info btn-sm">reset</a>
      </td>
      <td class="text-center">
        <form action="<?php echo e(route('staff.remove', $row->staff_id)); ?>"
              method="POST" class="d-inline"
              onsubmit="return confirmDelete(event, this)">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <button type="submit" class="btn btn-danger btn-sm">delete</button>
        </form>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<div><?php echo e($staffList->links()); ?></div>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function confirmDelete(e, form){
  if (typeof Swal === 'undefined') {
    return confirm('ลบเลย?');
  }
  e.preventDefault();
  Swal.fire({
    title: 'แน่ใจหรือไม่?',
    text: 'ลบแล้วกู้คืนไม่ได้',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'ลบเลย',
    cancelButtonText: 'ยกเลิก'
  }).then((result) => {
    if (result.isConfirmed) form.submit();
  });
  return false;
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pr\resources\views/staff/list.blade.php ENDPATH**/ ?>