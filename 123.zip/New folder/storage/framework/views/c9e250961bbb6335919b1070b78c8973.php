<?php $__env->startSection('css_before'); ?>
<?php $__env->startSection('navbar'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('showGundam'); ?>


<div class="container mt-4">
    <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-6">

            <h3>:: form Login ::</h3>

<form method="POST" action="<?php echo e(url('/login')); ?>">
  <?php echo csrf_field(); ?>

  <input type="text" name="staff_username"
         class="form-control mb-2"
         placeholder="email/username"
         value="<?php echo e(old('staff_username')); ?>" required>

  <input type="password" name="staff_password"
         class="form-control mb-3"
         placeholder="Password" required>

  <?php $__errorArgs = ['staff_username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  <?php $__errorArgs = ['staff_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

  <button class="btn btn-primary">Login</button>
  <a href="<?php echo e(url('/')); ?>" class="btn btn-danger">cancel</a>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontendAuth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pr\resources\views/auth//login.blade.php ENDPATH**/ ?>