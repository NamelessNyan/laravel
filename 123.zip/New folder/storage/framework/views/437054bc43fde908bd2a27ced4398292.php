<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebarMenu'); ?>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 


    <h3> :: Form Add Series :: </h3>

    <form action="/series/" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="form-group row mb-2">
            <label class="col-sm-2"> Series Name </label>
            <div class="col-sm-7">
                <input type="text" class="form-control" name="series_name" required placeholder="Series Name "
                    minlength="3" value="<?php echo e(old('series_name')); ?>">
                <?php if(isset($errors)): ?>
                <?php if($errors->has('series_name')): ?>
                <div class="text-danger"> <?php echo e($errors->first('series_name')); ?></div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="form-group row mb-2">
            <label class="col-sm-2"> Year </label>
            <div class="col-sm-7">
                <textarea name="year" class="form-control" rows="4" required
                    placeholder="Year"><?php echo e(old('year')); ?></textarea>
                <?php if(isset($errors)): ?>
                <?php if($errors->has('year')): ?>
                <div class="text-danger"> <?php echo e($errors->first('year')); ?></div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>


        <div class="form-group row mb-2">
            <label class="col-sm-2"> </label>
            <div class="col-sm-5">

                <button type="submit" class="btn btn-primary"> Insert Series </button>
                <a href="/series" class="btn btn-danger">cancel</a>
            </div>
        </div>

    </form>

</div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pr\resources\views/series/create.blade.php ENDPATH**/ ?>