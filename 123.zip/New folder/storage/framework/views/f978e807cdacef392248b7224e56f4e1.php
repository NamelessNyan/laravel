<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebarMenu'); ?>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 


<h3> :: Add Faction :: </h3>

<form action="<?php echo e(route('faction.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group row mb-2">
        <label class="col-sm-2"> Faction name </label>
        <div class="col-sm-7">
            <input type="text" class="form-control" name="faction_name"
                   required placeholder="Faction name" minlength="3"
                   value="<?php echo e(old('faction_name')); ?>">
            <?php $__errorArgs = ['faction_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>

    <div class="form-group row mb-2">
        <label class="col-sm-2"></label>
        <div class="col-sm-5">
            <button type="submit" class="btn btn-primary">Insert faction</button>
            <a href="<?php echo e(url('/faction')); ?>" class="btn btn-danger">cancel</a>
        </div>
    </div>
</form>


    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pr\resources\views/faction/create.blade.php ENDPATH**/ ?>