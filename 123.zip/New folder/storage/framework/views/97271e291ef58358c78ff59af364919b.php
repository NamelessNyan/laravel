<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sidebarMenu'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h3> :: Faction Managements ::
    <a href="<?php echo e(url('/faction/adding')); ?>" class="btn btn-primary btn-sm">Add Faction</a>
</h3>

<table class="table table-bordered table-striped table-hover">
    <thead>
        <tr class="table-info">
            <th width="8%"  class="text-center">No.</th>
            <th width="15%" class="text-center">Faction ID</th>
            <th>Faction Name</th>
            <th width="12%" class="text-center">edit</th>
            <th width="12%" class="text-center">delete</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $faction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            
            <td class="text-center">
                <?php echo e(($faction->currentPage()-1)*$faction->perPage() + $loop->iteration); ?>

            </td>

            <td class="text-center"><?php echo e($row->faction_id); ?></td>
            <td><?php echo e($row->faction_name); ?></td>

            <td class="text-center">
                <a href="<?php echo e(url('/faction/'.$row->faction_id)); ?>" class="btn btn-warning btn-sm">edit</a>
            </td>

            <td class="text-center">
                <button type="button" class="btn btn-danger btn-sm"
                        onclick="deleteConfirm(<?php echo e($row->faction_id); ?>)">delete</button>

                <form id="delete-form-<?php echo e($row->faction_id); ?>"
                      action="<?php echo e(url('/faction/remove/'.$row->faction_id)); ?>"
                      method="POST" style="display:none;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div>
    <?php echo e($faction->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_before'); ?>
<?php $__env->stopSection(); ?>




<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
function deleteConfirm(id) {
    Swal.fire({
        title: 'แน่ใจหรือไม่?',
        text: "คุณต้องการลบข้อมูลนี้จริง ๆ หรือไม่",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'ใช่, ลบเลย!',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('delete-form-' + id).submit();
        }
    })
}
</script>

<?php echo $__env->make('home', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pr\resources\views/faction/list.blade.php ENDPATH**/ ?>