<?php

namespace App\Models;

use Illuminate\Foundation\Auth\user as Authenticatable;
use Illuminate\Database\Eloquent\Model;


class StaffModel extends Authenticatable
{
    protected $table = 'tbl_staff';
    protected $primaryKey = 'staff_id'; // ตั้งให้ตรงกับชื่อจริงใน DB
    protected $fillable = ['staff_name', 'staff_username', 'staff_password', 'dateCreate'];
    public $incrementing = true; // ถ้า primary key เป็นตัวเลข auto increment
    public $timestamps = false;

    public function getAuthPassword()
    {
        return $this->staff_password;
    }

        public function getAuthIdentifierName()
        { 
            return 'staff_username'; 
        }

}


