<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FactionModel extends Model
{
    protected $table = 'tbl_faction';
    protected $primaryKey = 'faction_id'; // ตั้งให้ตรงกับชื่อจริงใน DB
    protected $keyType = 'int';
    protected $fillable = ['faction_name','dateCreate'];
    public $incrementing = true; // ถ้า primary key เป็นตัวเลข auto increment
    public $timestamps = false; // ใส่บรรทัดนี้ถ้าไม่มี created_at, updated_at
}



