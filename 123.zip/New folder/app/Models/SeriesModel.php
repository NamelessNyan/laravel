<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SeriesModel extends Model
{
    protected $table = 'tbl_series';
    protected $primaryKey = 'series_id';
    public $timestamps = false;
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = ['series_name','year','dateCreate'];
}
