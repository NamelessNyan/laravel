<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GundamModel extends Model
{
    protected $table = 'tbl_gundam';
    protected $primaryKey = 'gundam_id';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = false; // ไม่มี created_at / updated_at

    protected $fillable = [
        'gundam_name','gundam_model_no','faction_id','series_id',
        'height_m','weight_kg','gundam_image_url','description','dateCreate'
    ];
}

