<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\CounterModel;

class CountVisit
{
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);

        try {
            if ($request->isMethod('get') && !$request->is('storage/*') && !$request->ajax()) {
                CounterModel::create([
                    'ip'         => $request->ip(),
                    'user_agent' => substr((string)$request->userAgent(), 0, 255),
                    'path'       => substr($request->path(), 0, 255),
                    'c_date'     => now(),
                ]);
            }
        } catch (\Throwable $e) {
            // ignore
        }

        return $response;
    }
}
