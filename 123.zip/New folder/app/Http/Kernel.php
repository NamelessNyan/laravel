<?php  

protected $middlewareGroups = [
    'web' => [
        // ...
        \RealRashid\SweetAlert\ToSweetAlert::class,
    ],
    // ...
];

protected $middlewareGroups = [
    'web' => [
        // ...
        \App\Http\Middleware\CountVisit::class,
    ],
];
