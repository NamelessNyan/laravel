<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use RealRashid\SweetAlert\Facades\Alert;
use App\Models\StaffModel;
use App\Models\CounterModel;
use Illuminate\Support\Facades\Auth;


class AuthController extends Controller
{
    public function index()
    {
        return view('auth..login'); // แก้จาก auth..login
    }

    public function adding() {
        return view('staff.create');
    }

    public function login(Request $request)
    {
        $cred = $request->validate([
            'staff_username' => 'required|string|max:100',
            'staff_password' => 'required|string|min:3',
        ]);

        // ใช้ guard 'staff' (จะเทียบกับ getAuthPassword = staff_password)
        if (Auth::guard('staff')->attempt([
            'staff_username' => $cred['staff_username'],
            'password'       => $cred['staff_password'],
        ])) {
            $request->session()->regenerate();
            $user = Auth::guard('staff')->user();
            session(['staff_name' => $user->staff_name, 'staff_id' => $user->staff_id]);
            return redirect()->intended('/dashboard');
        }

        return back()->withErrors(['staff_username' => 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง'])
            ->withInput($request->only('staff_username'));
    }

    public function logout(Request $request)
    {
        Auth::guard('staff')->logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }
} //class