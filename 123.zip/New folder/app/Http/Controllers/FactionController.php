<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request; //รับค่าจากฟอร์ม
use Illuminate\Support\Facades\Validator; //form validation
use RealRashid\SweetAlert\Facades\Alert; //sweet alert
use Illuminate\Support\Facades\Storage; //สำหรับเก็บไฟล์ภาพ
use Illuminate\Pagination\Paginator; //แบ่งหน้า
use App\Models\FactionModel; //model



class FactionController extends Controller
{

    public function index(){
        Paginator::useBootstrap(); // ใช้ Bootstrap pagination
        $faction = FactionModel::orderBy('faction_id', 'desc')->paginate(5); //order by & pagination
         //return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
        return view('faction.list', compact('faction'));
    }

    public function adding() {
        return view('faction.create');
    }

public function create(Request $request)
{
    $data = $request->validate([
        'faction_name' => 'required|string|min:3|max:100|unique:tbl_faction,faction_name',
    ], [
        'faction_name.required' => 'กรุณากรอกชื่อฝ่าย/องค์กร',
        'faction_name.min'      => 'ต้องมีอย่างน้อย :min ตัวอักษร',
    ]);

    FactionModel::create([
        'faction_name' => strip_tags($data['faction_name']),
    ]);

    \RealRashid\SweetAlert\Facades\Alert::success('Insert Successfully');
    return redirect('/faction');
}


public function edit($id)
{
    $faction = FactionModel::findOrFail($id);
    $faction_id   = $faction->faction_id;      // <<< ใช้ชื่อคอลัมน์จริง
    $faction_name = $faction->faction_name;
    return view('faction.edit', compact('faction_id','faction_name'));
}

public function update($id, Request $request)
{
    $data = $request->validate([
        'faction_name' => 'required|string|min:3|max:100|unique:tbl_faction,faction_name,'.$id.',faction_id',
    ]);

    $faction = FactionModel::findOrFail($id);
    $faction->faction_name = strip_tags($data['faction_name']);
    $faction->save();

    \RealRashid\SweetAlert\Facades\Alert::success('Update Successfully');
    return redirect('/faction');
} 


public function remove($id)
{
    try {
        $faction = FactionModel::find($id); //คิวรี่เช็คว่ามีไอดีนี้อยู่ในตารางหรือไม่

        if (!$faction) {   //ถ้าไม่มี
            Alert::error('faction not found.');
            return redirect('faction');
        }

        //ถ้ามีภาพ ลบภาพในโฟลเดอร์ 
        if ($faction->faction_img && Storage::disk('public')->exists($faction->faction_img)) {
            Storage::disk('public')->delete($faction->faction_img);
        }

        // ลบข้อมูลจาก DB
        $faction->delete();

        Alert::success('Delete Successfully');
        return redirect('faction');

    } catch (\Exception $e) {
        Alert::error('เกิดข้อผิดพลาด: ' . $e->getMessage());
        return redirect('faction');
    }
} //remove 

//show faction with search
public function searchfaction(Request $request) {
    // print_r($_GET);
    // exit;

    Paginator::useBootstrap(); // 🟢 Enable Bootstrap pagination styling

    $keyword = $request->keyword;

    if (strlen($keyword) > 0) {
        // 🔍 Search faction by keyword in 'faction_name'
        $faction = FactionModel::where('faction_name', 'like', "%{$keyword}%")->paginate(8);
    } else {
        // 📦 If no keyword, show all faction, newest first
        $faction = FactionModel::orderBy('faction_id', 'desc')->paginate(8); // 8 per page
    }

    // 🖥️ Return to view with the faction and keyword
    return view('home.faction_index', compact('faction', 'keyword'));
}


} //class
