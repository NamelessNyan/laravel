<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request; //รับค่าจากฟอร์ม
use Illuminate\Support\Facades\Validator; //form validation
use RealRashid\SweetAlert\Facades\Alert; //sweet alert
use Illuminate\Support\Facades\Storage; //สำหรับเก็บไฟล์ภาพ
use Illuminate\Pagination\Paginator; //แบ่งหน้า
use App\Models\GundamModel; //model
use Illuminate\Validation\Rule;
use App\Models\SeriesModel; //model
use App\Models\FactionModel; //model



class GundamController extends Controller
{

    public function index()
    {
        Paginator::useBootstrap(); // ใช้ Bootstrap pagination
        $gundam = GundamModel::orderBy('gundam_id', 'desc')->paginate(5); //order by & pagination
        //return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
        return view('gundam.list', compact('gundam'));
    }

    public function adding()
    {
        $series   = SeriesModel::orderBy('series_name')->get();
        $factions = FactionModel::orderBy('faction_name')->get();

        return view('gundam.create', compact('series', 'factions'));
    }


    public function create(Request $request)
    {
        //msg
        $messages = [
            'gundam_name.required' => 'กรุณากรอกข้อมูล',
            'gundam_name.min' => 'ต้องมีอย่างน้อย :min ตัวอักษร',
            'gundam_model_no.required' => 'กรุณากรอกข้อมูล',
            'height_m.min' => 'ต้องมีอย่างน้อย :min ตัวอักษร',
            'height_m.max' => 'ห้ามเกิน :max ตัวอักษร',
            'weight_kg.min' => 'ต้องมีอย่างน้อย :min ตัวอักษร',
            'weight_kg.max' => 'ห้ามเกิน :max ตัวอักษร',
            'gundam_image_url.mimes' => 'รองรับ jpeg, png, jpg เท่านั้น !!',
            'gundam_image_url.max' => 'ขนาดไฟล์ไม่เกิน 5MB !!',
        ];

        //rule ตั้งขึ้นว่าจะเช็คอะไรบ้าง
        $validator = Validator::make($request->all(), [
            'gundam_name' => 'required|min:3',
            'height_m' => 'required|min:1|max:4',
            'weight_kg' => 'required|min:1|max:4',
            'gundam_image_url' => 'nullable|image|mimes:jpeg,png,jpg|max:5120',
        ], $messages);

        $request->validate([
            'gundam_name'     => 'required|min:3',
            'gundam_model_no' => 'required|string',
            'series_id'       => 'required|integer|exists:tbl_series,series_id',
            'faction_id'      => 'required|integer|exists:tbl_faction,faction_id',
            'gundam_img'      => 'nullable|image|mimes:jpeg,png,jpg|max:5120',
            'height_m'        => 'nullable|numeric',
            'weight_kg'       => 'nullable|numeric',
            'description'     => 'nullable|string',
        ]);



        //ถ้าผิดกฏให้อยู่หน้าเดิม และแสดง msg ออกมา
        if ($validator->fails()) {
            return redirect('gundam/adding')
                ->withErrors($validator)
                ->withInput();
        }


        //ถ้ามีการอัพโหลดไฟล์เข้ามา ให้อัพโหลดไปเก็บยังโฟลเดอร์ uploads/gundam
        try {
            $imagePath = null;
            if ($request->hasFile('gundam_image_url')) {
                $imagePath = $request->file('gundam_image_url')->store('uploads/gundam', 'public');
            }

            //insert เพิ่มข้อมูลลงตาราง
            GundamModel::create([
                'gundam_name' => strip_tags($request->gundam_name),
                'gundam_model_no' => strip_tags($request->gundam_mode_no),
                'gundam_image_url' => $imagePath,
            ]);

            //แสดง sweet alert
            Alert::success('Insert Successfully');
            return redirect('/gundam');
        } catch (\Exception $e) {  //error debug
            return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
            //return view('errors.404');
        }
    } //create 

    public function edit($id)
    {
        try {
            $gundam   = GundamModel::findOrFail($id); 
            $series   = SeriesModel::orderBy('series_name')->get();
            $factions = FactionModel::orderBy('faction_name')->get();

            // ส่งอ็อบเจ็กต์ตรง ๆ ให้ blade ใช้ $gundam->gundam_name ฯลฯ
            return view('gundam.edit', compact('gundam', 'series', 'factions'));
        } catch (\Exception $e) {
            return view('errors.404');
        }
    }

    public function update($id, Request $request)
    {
        //error msg
        $messages = [
            'gundam_id.required' => 'กรุณากรอกข้อมูล',
            'gundam_id.min' => 'ต้องมีอย่างน้อย :min ตัวอักษร',
            'gundam_name.required' => 'กรุณากรอกข้อมูล',
            'gundam_name.min' => 'ต้องมีอย่างน้อย :min ตัวอักษร',
            'gundam_model_no.required' => 'กรุณากรอกข้อมูล',
            'height_m.min' => 'ต้องมีอย่างน้อย :min ตัวอักษร',
            'height_m.max' => 'ห้ามเกิน :max ตัวอักษร',
            'weight_kg.min' => 'ต้องมีอย่างน้อย :min ตัวอักษร',
            'weight_kg.max' => 'ห้ามเกิน :max ตัวอักษร',
            'gundam_image_url.mimes' => 'รองรับ jpeg, png, jpg เท่านั้น !!',
            'gundam_image_url.max' => 'ขนาดไฟล์ไม่เกิน 5MB !!',
        ];

        // ตรวจสอบข้อมูลจากฟอร์มด้วย Validator
        $validator = Validator::make($request->all(), [
            'gundam_id' => [
                'required',
                'min:3',
                Rule::unique('tbl_gundam', 'gundam_id')->ignore($id, 'gundam_id'), //ห้ามแก้ซ้ำ
            ],
            'gundam_name' => 'required|min:1',
            'gundam_model_no' => 'required|min:1|max:10',
            'height_m' => 'required|min:1|max:4',
            'weight_kg' => 'required|min:1|max:4',
            'gundam_image_url' => 'nullable|image|mimes:jpeg,png,jpg|max:5120',
        ], $messages);

        $request->validate([
            'gundam_name'     => 'required|min:3',
            'gundam_model_no' => 'required|string',
            'series_id'       => 'required|integer|exists:tbl_series,series_id',
            'faction_id'      => 'required|integer|exists:tbl_faction,faction_id', // <-- ต้องเลือก
            'gundam_img'      => 'nullable|image|mimes:jpeg,png,jpg|max:5120',
            'height_m'        => 'nullable|numeric',
            'weight_kg'       => 'nullable|numeric',
            'description'     => 'nullable|string',
        ]);


        // ถ้า validation ไม่ผ่าน ให้กลับไปหน้าฟอร์มพร้อมแสดง error และข้อมูลเดิม
        if ($validator->fails()) {
            return redirect('gundam/' . $id . '/edit')
                ->withErrors($validator)
                ->withInput();
        }

        try {
            // ดึงข้อมูลสินค้าตามไอดี ถ้าไม่เจอจะ throw Exception
            $gundam = GundamModel::findOrFail($id);

            // ตรวจสอบว่ามีไฟล์รูปใหม่ถูกอัปโหลดมาหรือไม่
            if ($request->hasFile('gundam_image_url')) {
                // ถ้ามีรูปเดิมให้ลบไฟล์รูปเก่าออกจาก storage
                if ($gundam->gundam_image_url) {
                    Storage::disk('public')->delete($gundam->gundam_image_url);
                }
                // บันทึกไฟล์รูปใหม่ลงโฟลเดอร์ 'uploads/gundam' ใน disk 'public'
                $imagePath = $request->file('gundam_image_url')->store('uploads/gundam', 'public');
                // อัปเดต path รูปภาพใหม่ใน model
                $gundam->gundam_image_url = $imagePath;
            }

            // อัปเดตชื่อสินค้า โดยใช้ strip_tags ป้องกันการแทรกโค้ด HTML/JS
            $gundam->gundam_name = strip_tags($request->gundam_name);
            // อัปเดตรายละเอียดสินค้า โดยใช้ strip_tags ป้องกันการแทรกโค้ด HTML/JS
            $gundam->gundam_detail = strip_tags($request->gundam_detail);
            // อัปเดตราคาสินค้า
            $gundam->gundam_price = $request->gundam_price;

            // บันทึกการเปลี่ยนแปลงในฐานข้อมูล
            $gundam->save();

            // แสดง SweetAlert แจ้งว่าบันทึกสำเร็จ
            Alert::success('Update Successfully');

            // เปลี่ยนเส้นทางกลับไปหน้ารายการสินค้า
            return redirect('/series');
        } catch (\Exception $e) {
            //return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
            return view('errors.404');

            //return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
            //return view('errors.404');
        }
    } //update  



    public function remove($id)
    {
        try {
            $gundam = GundamModel::find($id); //คิวรี่เช็คว่ามีไอดีนี้อยู่ในตารางหรือไม่

            if (!$gundam) {   //ถ้าไม่มี
                Alert::error('gundam not found.');
                return redirect('gundam');
            }

            //ถ้ามีภาพ ลบภาพในโฟลเดอร์ 
            if ($gundam->gundam_image_url && Storage::disk('public')->exists($gundam->gundam_image_url)) {
                Storage::disk('public')->delete($gundam->gundam_image_url);
            }

            // ลบข้อมูลจาก DB
            $gundam->delete();

            Alert::success('Delete Successfully');
            return redirect('gundam');
        } catch (\Exception $e) {
            Alert::error('เกิดข้อผิดพลาด: ' . $e->getMessage());
            return redirect('gundam');
        }
    } //remove 



} //class
