<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request; //รับค่าจากฟอร์ม
use Illuminate\Support\Facades\Validator; //form validation
use RealRashid\SweetAlert\Facades\Alert; //sweet alert
use Illuminate\Support\Facades\Storage; //สำหรับเก็บไฟล์ภาพ
use Illuminate\Pagination\Paginator; //แบ่งหน้า
use App\Models\GundamModel; //model
use Illuminate\Support\Facades\DB;


class HomeController extends Controller
{

    public function index(){
        Paginator::useBootstrap(); // ใช้ Bootstrap pagination
        $products = GundamModel::orderBy('id', 'desc')->paginate(8); //order by & pagination
        
        DB::table('tbl_counter')->insert([
                'c_date' => now()   // บันทึกวันที่และเวลาปัจจุบัน
        ]);

        return view('home.product_index', compact('products'));
    }
    


public function detail($id)
    {
        try {
            $gundam = GundamModel::findOrFail($id); // ใช้ findOrFail เพื่อให้เจอหรือ 404

            //ประกาศตัวแปรเพื่อส่งไปที่ view
            if (isset($gundam)) {
                $id = $gundam->id;
                $gundam_name = $gundam->gundam_name;
                $gundam_detail = $gundam->gundam_detail;
                $gundam_price = $gundam->gundam_price;
                $gundam_img = $gundam->gundam_image_url;
                return view('home.gundam_detail', compact('id', 'gundam_name', 'gundam_model_no','faction_id','series_id', 'height_m', 'weight_kg','gundam_image_url','description'));
            }
        } catch (\Exception $e) {
            //return response()->json(['error' => $e->getMessage()], 500); //สำหรับ debug
            #return view('errors.404');
            return view('/');
        }
    } //func edit

    //show Gundam with search
public function searchGundam(Request $request) {
        // print_r($_GET);
        // exit;
        Paginator :: useBootstrap(); // Iy Bootstrap pagination
        $keyword = $request->keyword;
        if(strlen($keyword) > 0){
            //query data by searching
            $gundams = GundamModel::where('gundam_name', 'like', "%{$keyword}%")->paginate(8);
        }else{
            $gundams = GundamModel:: orderBy('id', 'desc' )->paginate(8); //8 produc/page
        }
return view('home.gundam_index', compact('gundams', 'keyword') );

} //searchGundam

} //class
