<?php

namespace App\Http\Controllers;

use App\Models\GundamModel;
use App\Models\StaffModel;
use App\Models\CounterModel;
use App\Models\FactionModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\QueryException;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:staff');
    }

    public function index()
    {
        // Cards
        $countFaction = FactionModel::count();
        $countGundam  = (int) GundamModel::count();
        $countProduct = $countGundam;
        $countStaff   = (int) StaffModel::count();

        try {
            $countView = (int) CounterModel::count();
        } catch (QueryException $e) {
            $countView = 0;
        }

        // 12 เดือนล่าสุด (เก่า -> ใหม่)
        $months = collect(range(0, 11))
            ->map(fn($i) => Carbon::now()->startOfMonth()->subMonths(11 - $i));
        $start  = $months->first();
        $end    = $months->last()->copy()->endOfMonth();

        $map = collect();
        try {
            $rows = DB::table('tbl_counter')
                ->selectRaw('DATE_FORMAT(c_date, "%Y-%m") as ym, COUNT(*) as total')
                ->whereBetween('c_date', [$start, $end])
                ->groupBy('ym')
                ->pluck('total', 'ym');
            $map = collect($rows);
        } catch (QueryException $e) {
            $map = collect();
        }

        $label = [];
        $data  = [];
        foreach ($months as $m) {
            $ym = $m->format('Y-m');
            $label[] = $m->format('M-Y'); // ต้องการไทยให้ setLocale('th') แล้วใช้ isoFormat
            $data[]  = (int) ($map[$ym] ?? 0);
        }

        return view('dashboard.index', compact(
            'countFaction','countGundam','countProduct','countStaff','countView','label','data'
        ));
    }
}
