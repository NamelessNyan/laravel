<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use RealRashid\SweetAlert\Facades\Alert;
use App\Models\StaffModel;
use Illuminate\Pagination\Paginator;

class StaffController extends Controller
{
    public function index()
    {
        try {
            Paginator::useBootstrap();
            $staffList = StaffModel::orderBy('staff_id', 'desc')->paginate(10);
            return view('staff.list', compact('staffList'));
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
            // return view('errors.404');
        }
    }

    public function adding()
    {
        return view('staff.create');
    }

    public function create(Request $request)
    {
        // msg
        $messages = [
            'staff_username.required' => 'กรุณากรอกข้อมูล',
            'staff_username.email'    => 'รูปแบบอีเมลไม่ถูกต้อง',
            'staff_username.unique'   => 'อีเมล/ชื่อผู้ใช้ซ้ำ',

            'staff_password.required' => 'กรุณากรอกรหัสผ่าน',
            'staff_password.min'      => 'กรอกขั้นต่ำ :min ตัวอักษร',

            'staff_name.required'     => 'กรุณากรอกชื่อ',
            'staff_name.min'          => 'กรอกขั้นต่ำ :min ตัวอักษร',
        ];

        // rule
        $validator = Validator::make($request->all(), [
            'staff_username' => 'required|email|unique:tbl_staff,staff_username',
            'staff_password' => 'required|string|min:3',
            'staff_name'     => 'required|string|min:3',
        ], $messages);

        if ($validator->fails()) {
            return redirect('staff/adding')->withErrors($validator)->withInput();
        }

        try {
            StaffModel::create([
                'staff_name'     => strip_tags($request->input('staff_name')),
                'staff_username' => strip_tags($request->input('staff_username')),
                'staff_password' => bcrypt($request->input('staff_password')),
            ]);
            Alert::success('เพิ่มข้อมูลสำเร็จ');
            return redirect('/staff');
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
            // return view('errors.404');
        }
    } // create

    public function edit($id)
    {
        try {
            $staff = StaffModel::findOrFail($id);
            if (isset($staff)) {
                $staff_id       = $staff->staff_id;
                $staff_name     = $staff->staff_name;
                $staff_username = $staff->staff_username;
                return view('staff.edit', compact('staff_id', 'staff_name', 'staff_username'));
            }
        } catch (\Exception $e) {
            // return response()->json(['error' => $e->getMessage()], 500);
            return view('errors.404');
        }
    } // edit

    public function update($id, Request $request)
    {
        // msg
        $messages = [
            'staff_name.required'     => 'กรุณากรอกชื่อ',
            'staff_name.min'          => 'กรอกขั้นต่ำ :min ตัวอักษร',

            'staff_username.required' => 'กรุณากรอกอีเมล',
            'staff_username.email'    => 'รูปแบบอีเมลไม่ถูกต้อง',
            'staff_username.unique'   => 'อีเมล/ชื่อผู้ใช้ซ้ำ',
        ];

        // rule
        $validator = Validator::make($request->all(), [
            'staff_name'     => 'required|string|min:3',
            'staff_username' => [
                'required', 'email',
                Rule::unique('tbl_staff', 'staff_username')->ignore($id, 'staff_id'),
            ],
        ], $messages);

        if ($validator->fails()) {
            return redirect('staff/' . $id)->withErrors($validator)->withInput();
        }

        try {
            $staff = StaffModel::findOrFail($id);
            $staff->update([
                'staff_name'     => strip_tags($request->input('staff_name')),
                'staff_username' => strip_tags($request->input('staff_username')),
                // แก้รหัสผ่านตรงนี้ถ้าส่งมา (ตัวเลือก)
                // 'staff_password' => $request->filled('staff_password') ? bcrypt($request->input('staff_password')) : $staff->staff_password,
            ]);
            Alert::success('ปรับปรุงข้อมูลสำเร็จ');
            return redirect('/staff');
        } catch (\Exception $e) {
            // return response()->json(['error' => $e->getMessage()], 500);
            return view('errors.404');
        }
    } // update

    public function remove($id)
    {
        try {
            $staff = StaffModel::find($id);
            if (!$staff) {
                Alert::error('ไม่พบข้อมูล');
                return redirect('/staff');
            }
            $staff->delete();
            Alert::success('ลบข้อมูลสำเร็จ');
            return redirect('/staff');
        } catch (\Exception $e) {
            // return response()->json(['error' => $e->getMessage()], 500);
            return view('errors.404');
        }
    } // remove

    public function reset($id)
    {
        try {
            $staff = StaffModel::findOrFail($id);
            if (isset($staff)) {
                $staff_id       = $staff->staff_id;
                $staff_name     = $staff->staff_name;
                $staff_username = $staff->staff_username;
                return view('staff.editPassword', compact('staff_id', 'staff_name', 'staff_username'));
            }
        } catch (\Exception $e) {
            // return response()->json(['error' => $e->getMessage()], 500);
            return view('errors.404');
        }
    } // reset (show form)

    public function resetPassword($id, Request $request)
    {
        // msg
        $messages = [
            'password.required'          => 'กรุณากรอกรหัสผ่าน',
            'password.min'               => 'กรอกขั้นต่ำ :min ตัวอักษร',
            'password.confirmed'         => 'รหัสผ่านไม่ตรงกัน',
            'password_confirmation.required' => 'กรุณายืนยันรหัสผ่าน',
            'password_confirmation.min'      => 'กรอกขั้นต่ำ :min ตัวอักษร',
        ];

        // rule
        $validator = Validator::make($request->all(), [
            'password'              => 'required|string|min:3|confirmed',
            'password_confirmation' => 'required|string|min:3',
        ], $messages);

        if ($validator->fails()) {
            return redirect('staff/reset/' . $id)->withErrors($validator)->withInput();
        }

        try {
            $staff = StaffModel::findOrFail($id);
            $staff->update([
                'staff_password' => bcrypt($request->input('password')),
            ]);
            Alert::success('แก้ไขรหัสผ่านสำเร็จ');
            return redirect('/staff');
        } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
            // return view('errors.404');
        }
    } // resetPassword
}

