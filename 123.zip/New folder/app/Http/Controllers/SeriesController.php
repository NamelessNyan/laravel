<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use App\Models\SeriesModel;
use RealRashid\SweetAlert\Facades\Alert;

class SeriesController extends Controller
{
    public function index()
    {
        Paginator::useBootstrap();
        $series = SeriesModel::orderBy('series_id','desc')->paginate(10);
        return view('series.list', compact('series'));
    }

    public function adding()
    {
        return view('series.create');
    }

    // POST /series
    public function create(Request $request)
    {
        $data = $request->validate([
            'series_name' => 'required|string|min:2|max:200|unique:tbl_series,series_name',
            'year'        => 'nullable|integer|min:1900|max:2100',
        ]);

        SeriesModel::create([
            'series_name' => strip_tags($data['series_name']),
            'year'        => $data['year'] ?? null,
        ]);

        Alert::success('Insert Successfully');
        return redirect('/series');
    }

    // GET /series/{id}
    public function edit($id)
    {
        $row = SeriesModel::findOrFail($id);
        $series_id   = $row->series_id;
        $series_name = $row->series_name;
        $year        = $row->year;

        return view('series.edit', compact('series_id','series_name','year'));
    }

    // PUT /series/{id}
    public function update($id, Request $request)
    {
        $data = $request->validate([
            'series_name' => 'required|string|min:2|max:200|unique:tbl_series,series_name,' . $id . ',series_id',
            'year'        => 'nullable|integer|min:1900|max:2100',
        ]);

        $row = SeriesModel::findOrFail($id);
        $row->series_name = strip_tags($data['series_name']);
        $row->year        = $data['year'] ?? null;
        $row->save();

        Alert::success('Update Successfully');
        return redirect('/series');
    }

    // DELETE /series/remove/{id}
    public function remove($id)
    {
        $row = SeriesModel::find($id);
        if (!$row) {
            Alert::error('Series not found');
            return redirect('/series');
        }
        $row->delete();
        Alert::success('Delete Successfully');
        return redirect('/series');
    }
}
