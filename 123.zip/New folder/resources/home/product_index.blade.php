@extends('frontend')
@section('css_before')
@section('navbar')
@endsection

@section('showProduct')

    @foreach($products as $data)
    <div class="col-12 col-sm-4 col-md-4 col-lg-3 mb-2">
      <div class="card" style="width: 100%;">
        <a href="#">
          <img src="" class="card-img-top" alt="devbanban.com">
        </a>
        <div class="card-body">
          <h5 class="card-title">
            <a href="#" class="link-offset-2 link-underline link-underline-opacity-0">
              show product name  xxx
            </a>
          </h5>
          <p class="card-text">Price xxxx THB.</p>
          <a href="#" class="btn btn-success">more detail click...</a>
        </div>
      </div>
    </div>
    @endforeach



  <div class="row mt-2 mb-2">
    <!-- Pagination links -->
    <div class="col-sm-5 col-md-5"></div>
    <div class="col-sm-3 col-md-3">
      <center>
        {{ $products->links() }}
      </center>
    </div>
</div>




@endsection

@section('footer')
@endsection

@section('js_before')
@endsection

{{-- devbanban.com --}}