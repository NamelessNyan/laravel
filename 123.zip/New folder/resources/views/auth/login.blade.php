@extends('frontendAuth')
@section('css_before')
@section('navbar')
@endsection

@section('showGundam')


<div class="container mt-4">
    <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-6">

            <h3>:: form Login ::</h3>

<form method="POST" action="{{ url('/login') }}">
  @csrf

  <input type="text" name="staff_username"
         class="form-control mb-2"
         placeholder="email/username"
         value="{{ old('staff_username') }}" required>

  <input type="password" name="staff_password"
         class="form-control mb-3"
         placeholder="Password" required>

  @error('staff_username') <div class="text-danger">{{ $message }}</div> @enderror
  @error('staff_password') <div class="text-danger">{{ $message }}</div> @enderror

  <button class="btn btn-primary">Login</button>
  <a href="{{ url('/') }}" class="btn btn-danger">cancel</a>
</form>

@endsection

@section('footer')
@endsection

@section('js_before')
@endsection

{{-- devbanban.com --}}