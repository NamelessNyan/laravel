@extends('frontend')
@section('css_before')
@section('navbar')
@endsection
@section('showGundam')

<div class="col-12 col-sm-3 col-md-3 mb-2">
    <div class="card" style="width: 100%;">
        <img src="{{ asset('storage/' . $gundam_image_url) }}" class="card-img-top" alt="devbanban.com">
    </div>
</div>
<div class="col-12 col-sm-8 col-md-8 mb-2">
    <h5 class="card-title">{{ $gundam_name }}, NO. {{ number_format($gundam_model_no) }} </h5>
    <p>
        gundam detail
        <br>
        {{ $gundam_detail }}
    </p>
</div>

@endsection

@section('footer')
@endsection

@section('js_before')
@endsection

{{-- devbanban.com --}}