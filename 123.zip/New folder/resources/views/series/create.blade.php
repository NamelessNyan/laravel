@extends('home')
@section('css_before')
@endsection
@section('header')
@endsection
@section('sidebarMenu')   
@endsection
@section('content')
 


    <h3> :: Form Add Series :: </h3>

    <form action="/series/" method="post" enctype="multipart/form-data">
        @csrf

        <div class="form-group row mb-2">
            <label class="col-sm-2"> Series Name </label>
            <div class="col-sm-7">
                <input type="text" class="form-control" name="series_name" required placeholder="Series Name "
                    minlength="3" value="{{ old('series_name') }}">
                @if(isset($errors))
                @if($errors->has('series_name'))
                <div class="text-danger"> {{ $errors->first('series_name') }}</div>
                @endif
                @endif
            </div>
        </div>

        <div class="form-group row mb-2">
            <label class="col-sm-2"> Year </label>
            <div class="col-sm-7">
                <textarea name="year" class="form-control" rows="4" required
                    placeholder="Year">{{ old('year') }}</textarea>
                @if(isset($errors))
                @if($errors->has('year'))
                <div class="text-danger"> {{ $errors->first('year') }}</div>
                @endif
                @endif
            </div>
        </div>


        <div class="form-group row mb-2">
            <label class="col-sm-2"> </label>
            <div class="col-sm-5">

                <button type="submit" class="btn btn-primary"> Insert Series </button>
                <a href="/series" class="btn btn-danger">cancel</a>
            </div>
        </div>

    </form>

</div>

    
@endsection

@section('footer')
@endsection

@section('js_before')
@endsection

{{-- devbanban.com --}}