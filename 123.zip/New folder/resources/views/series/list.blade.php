@extends('home')

@section('css_before')
@endsection

@section('header')
@endsection

@section('sidebarMenu')
@endsection

@section('content')
<h3> :: Series Managements ::
    <a href="{{ url('/series/adding') }}" class="btn btn-primary btn-sm">Add Series</a>
</h3>

<table class="table table-bordered table-striped table-hover">
    <thead>
        <tr class="table-info">
            <th width="5%"  class="text-center">No.</th>
            <th width="15%" class="text-center">Series ID</th>
            <th width="65%">Series Name</th>
            <th width="15%" class="text-center">Year</th>
            <th width="5%"  class="text-center">edit</th>
            <th width="5%"  class="text-center">delete</th>
        </tr>
    </thead>
    <tbody>
        @foreach($series as $row)
        <tr>
            {{-- running number across pagination --}}
            <td class="text-center">
                {{ ($series->currentPage()-1)*$series->perPage() + $loop->iteration }}
            </td>

            <td class="text-center">   
                {{ $row->series_id }}
            </td>

            <td>
                <b>{{ $row->series_name }}</b>
            </td>

            {{-- แสดงปีตรง ๆ ไม่ format เป็นทศนิยม --}}
            <td class="text-center">{{ $row->year }}</td>

            <td class="text-center">
                <a href="{{ url('/series/'.$row->series_id) }}" class="btn btn-warning btn-sm">edit</a>
            </td>

            <td class="text-center">
                <button type="button" class="btn btn-danger btn-sm"
                        onclick="deleteConfirm({{ $row->series_id }})">delete</button>

                <form id="delete-form-{{ $row->series_id }}"
                      action="{{ url('/series/remove/'.$row->series_id) }}"
                      method="POST" style="display:none;">
                    @csrf
                    @method('delete')
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

<div>
    {{ $series->links() }}
</div>
@endsection

@section('footer')
@endsection

@section('js_before')
@endsection

@section('js_before')
@endsection




<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function deleteConfirm(id) {
    Swal.fire({
        title: 'แน่ใจหรือไม่?',
        text: "คุณต้องการลบข้อมูลนี้จริง ๆ หรือไม่",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'ใช่, ลบเลย!',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('delete-form-' + id).submit();
        }
    })
}
</script>

