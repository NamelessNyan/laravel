@extends('home')

@section('content')
<h3> :: form Update Series :: </h3>

<form action="{{ url('/series/'.$series_id) }}" method="post">
    @csrf
    @method('put')

    <div class="form-group row mb-2">
        <label class="col-sm-2"> Series Name </label>
        <div class="col-sm-7">
            <input type="text" class="form-control" name="series_name"
                   placeholder="Series Name" minlength="2" maxlength="200" required
                   value="{{ old('series_name', $series_name) }}">
            @error('series_name') <div class="text-danger">{{ $message }}</div> @enderror
        </div>
    </div>

    <div class="form-group row mb-2">
        <label class="col-sm-2"> Year </label>
        <div class="col-sm-7">
            <input type="number" name="year" class="form-control"
                   min="1900" max="2100" placeholder="เช่น 2021"
                   value="{{ old('year', $year) }}">
            @error('year') <div class="text-danger">{{ $message }}</div> @enderror
        </div>
    </div>

    <div class="form-group row mb-2">
        <label class="col-sm-2"> </label>
        <div class="col-sm-5">
            <button type="submit" class="btn btn-primary"> Update </button>
            <a href="{{ url('/series') }}" class="btn btn-danger">cancel</a>
        </div>
    </div>
</form>
@endsection
