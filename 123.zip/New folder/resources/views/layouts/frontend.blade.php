
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gund4m D4rkF1meMas1er</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
    @yield('css_before')
  </head>
  <body>

    <!-- start navbar  --> 
<div class="container">
    <div class="row">
    <div class="col-12 col-sm-12 col-md-12">
<nav class="navbar navbar-expand-lg bg-primary">
    <div class="container">
      <a class="navbar-brand text-white" href="/">Gund4m Mas1er</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href="/">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="/gundam">Gundam List</a>
          </li>
          <li class="nav-item">
            <a class="nav-link text-white" href="/series">Series</a>
          </li>

           <li class="nav-item">
            <a class="nav-link text-white" href="/login">Login</a>
          </li>


          
          <li class="nav-item">
            <a class="nav-link text-white" href="/dashboard" target="_blank">NULL</a>
          </li>
          
        </ul>
        <form action="/search" method="get" class="d-flex" role="search">
          <input class="form-control me-2" type="text" name="keyword" placeholder="Search Product Name" aria-label="Search" required value="{{ $keyword ?? ''}}">
          <button class="btn btn-success" type="submit">Search </button>
        </form>
      </div>
    </div>
  </nav>
    </div>
    </div>
</div>
  <!-- end navbar  -->

  <div class="container mt-2 mb-2">
    <div class="row">
      <div class="col-12 col-sm-12 col-md-12">
        <div class="alert alert-primary" role="alert">
          ::show gundam::
        </div>
      </div>
    </div>
  </div>
  @yield('navbar')




  <div class="container mt-2">
    <div class="row">
        @yield('showGundam')
    </div>
  </div>


    <footer class="mt-5 mb-2">
      <p class="text-center">by devbanban.com @2025</p>
    </footer>
    
    @yield('footer')

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/js/bootstrap.bundle.min.js" integrity="sha384-k6d4wzSIapyDyv1kpU366/PK5hCdSbCRGRCMv+eplOQJWyd1fbcAu9OCUj5zNLiq" crossorigin="anonymous"></script>

    @yield('js_before')

  </body>
</html>
