@extends('home')

@section('content')
<h1>staff data
  <a href="{{ route('staff.add') }}" class="btn btn-primary btn-sm mb-2">+ staff</a>
</h1>

<table class="table table-bordered table-striped table-hover">
  <thead>
    <tr class="table-info">
      <th width="5%" class="text-center">No.</th>
      <th width="30%">staff Name</th>
      <th width="20%">Email/Username</th>
      <th width="5%" class="text-center">edit</th>
      <th width="5%" class="text-center">PWD</th>
      <th width="5%" class="text-center">delete</th>
    </tr>
  </thead>
  <tbody>
  @foreach($staffList as $row)
    @php $no = ($staffList->currentPage()-1)*$staffList->perPage() + $loop->iteration; @endphp
    <tr>
      <td class="text-center">{{ $no }}.</td>
      <td>{{ $row->staff_name }}</td>
      <td>{{ $row->staff_username }}</td>
      <td class="text-center">
        <a href="{{ route('staff.edit', $row->staff_id) }}" class="btn btn-warning btn-sm">edit</a>
      </td>
      <td class="text-center">
        <a href="{{ route('staff.reset', $row->staff_id) }}" class="btn btn-info btn-sm">reset</a>
      </td>
      <td class="text-center">
        <form action="{{ route('staff.remove', $row->staff_id) }}"
              method="POST" class="d-inline"
              onsubmit="return confirmDelete(event, this)">
          @csrf
          @method('DELETE')
          <button type="submit" class="btn btn-danger btn-sm">delete</button>
        </form>
      </td>
    </tr>
  @endforeach
  </tbody>
</table>

<div>{{ $staffList->links() }}</div>

{{-- SweetAlert สำหรับยืนยันลบ (ถ้าโหลดไม่ได้ จะ fallback เป็น confirm() ของเบราเซอร์) --}}
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function confirmDelete(e, form){
  if (typeof Swal === 'undefined') {
    return confirm('ลบเลย?');
  }
  e.preventDefault();
  Swal.fire({
    title: 'แน่ใจหรือไม่?',
    text: 'ลบแล้วกู้คืนไม่ได้',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'ลบเลย',
    cancelButtonText: 'ยกเลิก'
  }).then((result) => {
    if (result.isConfirmed) form.submit();
  });
  return false;
}
</script>
@endsection
