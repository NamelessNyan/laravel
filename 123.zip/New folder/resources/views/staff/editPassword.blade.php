@extends('home')

@section('css_before')
@endsection

@section('header')
@endsection

@section('sidebarMenu')
@endsection

@section('content')

<div class="container mt-4">
    <div class="row">
        <div class="col-sm-12">

            <h3> :: Update Password :: </h3>

            <form action="{{ route('staff.resetPassword', $staff_id) }}" method="post">
                @csrf
                @method('put')

                <div class="form-group row mb-2">
                    <label class="col-sm-2"> name </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" disabled placeholder="name" value="{{ $staff_name }}">
                    </div>
                </div>

                <div class="form-group row mb-2">
                    <label class="col-sm-2"> Email/Username </label>
                    <div class="col-sm-6">
                        <input type="text" class="form-control" disabled placeholder="email" value="{{ $staff_username }}">
                    </div>
                </div>

                <div class="form-group row mb-2">
                    <label class="col-sm-2"> New Password </label>
                    <div class="col-sm-6">
                        <input type="password" class="form-control" name="password" required minlength="3"
                               placeholder="New Password 3 characters">
                        @if(isset($errors) && $errors->has('password'))
                            <div class="text-danger">{{ $errors->first('password') }}</div>
                        @endif
                    </div>
                </div>

                <div class="form-group row mb-2">
                    <label class="col-sm-2"> Confirm Password </label>
                    <div class="col-sm-6">
                        <input type="password" class="form-control" name="password_confirmation" required minlength="3"
                               placeholder="Confirm Password 3 characters">
                        @if(isset($errors) && $errors->has('password_confirmation'))
                            <div class="text-danger">{{ $errors->first('password_confirmation') }}</div>
                        @endif
                    </div>
                </div>

                <div class="form-group row mb-2">
                    <label class="col-sm-2"> </label>
                    <div class="col-sm-6">
                        <button type="submit" class="btn btn-primary"> Update </button>
                        <a href="{{ route('staff.index') }}" class="btn btn-danger">cancel</a>
                    </div>
                </div>

            </form>
        </div>
    </div>
</div>

@endsection

@section('footer')
@endsection

@section('js_before')
@endsection

@section('js_before')
@endsection
