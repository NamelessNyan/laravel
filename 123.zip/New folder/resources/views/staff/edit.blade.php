@extends('home')

@section('css_before')
@endsection

@section('header')
@endsection

@section('sidebarMenu')
@endsection

@section('content')

<div class="container mt-4">
  <div class="row">
    <div class="col-sm-12">
      <h3>:: Update staff ::</h3>

      <form action="{{ route('staff.update', $staff_id) }}" method="post">
        @csrf
        @method('put')

        <div class="form-group row mb-2">
          <label class="col-sm-2">staff Name</label>
          <div class="col-sm-6">
            <input type="text"
                   class="form-control"
                   name="staff_name"
                   required
                   minlength="3"
                   placeholder="staff name"
                   value="{{ old('staff_name', $staff_name) }}">
            @error('staff_name')
              <div class="text-danger">{{ $message }}</div>
            @enderror
          </div>
        </div>

        <div class="form-group row mb-2">
          <label class="col-sm-2">Email/Username</label>
          <div class="col-sm-6">
            <input type="email"
                   class="form-control"
                   name="staff_username"
                   required
                   placeholder="email/username"
                   value="{{ old('staff_username', $staff_username) }}">
            @error('staff_username')
              <div class="text-danger">{{ $message }}</div>
            @enderror
          </div>
        </div>

        <div class="form-group row mb-2">
          <label class="col-sm-2"></label>
          <div class="col-sm-6">
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="{{ route('staff.index') }}" class="btn btn-danger">cancel</a>
          </div>
        </div>
      </form>

    </div>
  </div>
</div>


@endsection

@section('footer')
@endsection

@section('js_before')
@endsection

@section('js_before')
@endsection