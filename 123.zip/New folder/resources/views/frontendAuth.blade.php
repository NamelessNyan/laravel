@extends('layouts.frontendAuth')

@section('css_before')
@endsection

@section('navbar')
@endsection
 
 
@section('showGundam')    
@endsection

 

@section('footer')
@endsection

@section('js_before')
@endsection
