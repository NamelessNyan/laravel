@extends('home')

@section('content')
  <h3> :: Gundam Managements ::
    <a href="{{ route('gundam.add') }}" class="btn btn-primary btn-sm">Add Gundam</a>
  </h3>

  <table class="table table-bordered table-striped table-hover">
    <thead>
      <tr class="table-info">
        <th width="5%" class="text-center">No.</th>
        <th width="6%" class="text-center">Gundam ID</th>
        <th width="10%" class="text-center">Pic</th>
        <th width="14%">Model No</th>
        <th width="24%">Name</th>
        <th width="12%" class="text-center">Height</th>
        <th width="12%" class="text-center">Weight</th>
        <th width="14%" class="text-center">Description</th>
        <th width="4%" class="text-center">edit</th>
        <th width="4%" class="text-center">delete</th>
      </tr>
    </thead>

    <tbody>
      @foreach($gundam as $row)
          @php $pk = $row->gundam_id ?? $row->id; @endphp
          <tr>
        <td align="center"> 
          {{ $loop->iteration }}
        </td>            
            <td class="text-center">{{ $pk }}</td>
            <td class="text-center">
              @if(!empty($row->gundam_image_url))
                <img src="{{ asset('storage/' . $row->gundam_image_url) }}" width="90">
              @else - @endif
            </td>
            <td>{{ $row->gundam_model_no ?? '-' }}</td>
            <td>{{ $row->gundam_name ?? '-' }}</td>
            <td class="text-center">{{ $row->gundam_height ?? '-' }}</td>
            <td class="text-center">{{ $row->gundam_weight ?? '-' }}</td>
            <td class="text-center">{{ \Illuminate\Support\Str::limit($row->gundam_description ?? '-', 100, '...') }}</td>
            <td class="text-center">
              <a href="{{ route('gundam.edit', $pk) }}" class="btn btn-warning btn-sm">edit</a>
            </td>
            <td class="text-center">
              <form action="{{ route('gundam.remove', $pk) }}" method="POST" class="d-inline"
                onsubmit="return confirmDelete(event, this)">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger btn-sm">delete</button>
              </form>
            </td>
          </tr>
      @endforeach
    </tbody>
  </table>

  <div>{{ $gundam->links() }}</div>

  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    function confirmDelete(e, form) {
      if (typeof Swal === 'undefined') {
        return confirm('ลบเลย?');
      }
      e.preventDefault();
      Swal.fire({
        title: 'แน่ใจหรือไม่?',
        text: 'ลบแล้วกู้คืนไม่ได้',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'ลบเลย',
        cancelButtonText: 'ยกเลิก'
      }).then((result) => {
        if (result.isConfirmed) form.submit();
      });
      return false;
    }
  </script>
@endsection