@extends('home')

@section('content')
<h3>:: Add Gundam ::</h3>

<form action="{{ route('gundam.store') }}" method="post" enctype="multipart/form-data">
  @csrf

  <div class="mb-3">
    <label class="form-label">Gundam Name</label>
    <input type="text" class="form-control" name="gundam_name" required minlength="3" value="{{ old('gundam_name') }}">
    @error('gundam_name') <div class="text-danger">{{ $message }}</div> @enderror
  </div>

  <div class="mb-3">
    <label class="form-label">Model No</label>
    <input type="text" class="form-control" name="gundam_model_no" required value="{{ old('gundam_model_no') }}">
    @error('gundam_model_no') <div class="text-danger">{{ $message }}</div> @enderror
  </div>

  <div class="mb-3">
    <label class="form-label">Series</label>
    <select class="form-control" name="series_id" required>
      <option value="">-- เลือก Series --</option>
      @foreach($series as $s)
        <option value="{{ $s->series_id }}" {{ old('series_id')==$s->series_id ? 'selected' : '' }}>
          {{ $s->series_name }}
        </option>
      @endforeach
    </select>
    @error('series_id') <div class="text-danger">{{ $message }}</div> @enderror
  </div>

  <div class="mb-3">
    <label class="form-label">Faction (ถ้ามี)</label>
    <select class="form-control" name="faction_id">
      <option value="">-- เลือก Faction --</option>
      @foreach($factions as $f)
        <option value="{{ $f->faction_id }}" {{ old('faction_id')==$f->faction_id ? 'selected' : '' }}>
          {{ $f->faction_name }}
        </option>
      @endforeach
    </select>
    @error('faction_id') <div class="text-danger">{{ $message }}</div> @enderror
  </div>

  <div class="row">
    <div class="col-md-6 mb-3">
      <label class="form-label">Height (m)</label>
      <input type="number" step="0.01" class="form-control" name="height_m" value="{{ old('height_m') }}">
      @error('height_m') <div class="text-danger">{{ $message }}</div> @enderror
    </div>
    <div class="col-md-6 mb-3">
      <label class="form-label">Weight (kg)</label>
      <input type="number" step="0.01" class="form-control" name="weight_kg" value="{{ old('weight_kg') }}">
      @error('weight_kg') <div class="text-danger">{{ $message }}</div> @enderror
    </div>
  </div>

  <div class="mb-3">
    <label class="form-label">Description</label>
    <textarea class="form-control" name="description" rows="4">{{ old('description') }}</textarea>
    @error('description') <div class="text-danger">{{ $message }}</div> @enderror
  </div>

  <div class="mb-3">
    <label class="form-label">Image</label>
    <input type="file" class="form-control" name="gundam_img" accept="image/*">
    @error('gundam_img') <div class="text-danger">{{ $message }}</div> @enderror
  </div>

  <button type="submit" class="btn btn-primary">Insert</button>
  <a href="{{ route('gundam.index') }}" class="btn btn-secondary">cancel</a>
</form>
@endsection
