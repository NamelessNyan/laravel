@extends('home')

@section('css_before')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
@endsection

@section('content')
<div class="container mt-4">
  <div class="row">
    <div class="col-md-12"><h4>Dashboard</h4></div>
  </div>
</div>

<div class="container mt-3">
  <div class="row g-3">
    <div class="col-md-3"><div class="alert alert-info mb-0" role="alert">
      <div class="fw-semibold">Faction</div>
      <div><strong>{{ number_format($countFaction ?? 0) }}</strong> Unit</div>
    </div></div>
    <div class="col-md-3"><div class="alert alert-primary mb-0" role="alert">
      <div class="fw-semibold">Gundam</div>
      <div><strong>{{ number_format($countProduct ?? 0) }}</strong> Unit</div>
    </div></div>
    <div class="col-md-3"><div class="alert alert-success mb-0" role="alert">
      <div class="fw-semibold">Staffs</div>
      <div><strong>{{ number_format($countStaff ?? 0) }}</strong> accounts</div>
    </div></div>
    <div class="col-md-3"><div class="alert alert-danger mb-0" role="alert">
      <div class="fw-semibold">Views</div>
      <div><strong>{{ number_format($countView ?? 0) }}</strong> views</div>
    </div></div>
  </div>
</div>

<div class="container mt-4">
  <div class="row">
    <div class="col-md-12">
      <h4>ข้อมูลกันดั้ม Staff และการเข้าชมเว็บไซต์</h4>
      <div style="height:300px"><canvas id="visitsChart"></canvas></div>
    </div>
  </div>
</div>
@endsection

@section('js_after')
<script>
(function(){
  const labels = @json($label ?? []);
  const dataPts = @json($data ?? []);
  const len = Math.min(labels.length, dataPts.length);
  const L = labels.slice(0, len);
  const D = dataPts.slice(0, len);

  const ctx = document.getElementById('visitsChart').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: { labels: L, datasets: [{
      label: 'เข้าชม (12 เดือนล่าสุด)',
      data: D,
      borderColor: 'rgba(54, 162, 235, 1)',
      backgroundColor: 'rgba(54, 162, 235, 0.2)',
      borderWidth: 2,
      tension: 0.3,
      fill: true,
      pointRadius: 3,
      pointHoverRadius: 5
    }]},
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: 'index', intersect: false },
      scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
    }
  });
})();
</script>
@endsection
