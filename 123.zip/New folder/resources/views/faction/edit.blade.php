@extends('home')
@section('js_before')
@include('sweetalert::alert')
@section('header')
@section('sidebarMenu')   
@section('content')

<h3> :: form Update Faction :: </h3>

<form action="{{ route('faction.update', $faction_id) }}" method="post" enctype="multipart/form-data">
    @csrf
    @method('put')

    <div class="form-group row mb-2">
        <label class="col-sm-2">Faction name</label>
        <div class="col-sm-7">
            <input type="text"
                   class="form-control"
                   name="faction_name"
                   required
                   placeholder="Faction name"
                   minlength="3"
                   value="{{ old('faction_name', $faction_name) }}">
            @error('faction_name')
              <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="form-group row mb-2">
        <label class="col-sm-2"></label>
        <div class="col-sm-5">
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="{{ route('faction.index') }}" class="btn btn-secondary">cancel</a>
        </div>
    </div>
</form>



@endsection


@section('footer')
@endsection

@section('js_before')
@endsection

{{-- devbanban.com --}}