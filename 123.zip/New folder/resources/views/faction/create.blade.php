@extends('home')
@section('css_before')
@endsection
@section('header')
@endsection
@section('sidebarMenu')   
@endsection
@section('content')
 


<h3> :: Add Faction :: </h3>

<form action="{{ route('faction.store') }}" method="post">
    @csrf
    <div class="form-group row mb-2">
        <label class="col-sm-2"> Faction name </label>
        <div class="col-sm-7">
            <input type="text" class="form-control" name="faction_name"
                   required placeholder="Faction name" minlength="3"
                   value="{{ old('faction_name') }}">
            @error('faction_name')
              <div class="text-danger">{{ $message }}</div>
            @enderror
        </div>
    </div>

    <div class="form-group row mb-2">
        <label class="col-sm-2"></label>
        <div class="col-sm-5">
            <button type="submit" class="btn btn-primary">Insert faction</button>
            <a href="{{ url('/faction') }}" class="btn btn-danger">cancel</a>
        </div>
    </div>
</form>


    
@endsection

@section('footer')
@endsection

@section('js_before')
@endsection

{{-- devbanban.com --}}