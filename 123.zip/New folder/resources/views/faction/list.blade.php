@extends('home')

@section('css_before')
@endsection

@section('header')
@endsection

@section('sidebarMenu')
@endsection

@section('content')
<h3> :: Faction Managements ::
    <a href="{{ url('/faction/adding') }}" class="btn btn-primary btn-sm">Add Faction</a>
</h3>

<table class="table table-bordered table-striped table-hover">
    <thead>
        <tr class="table-info">
            <th width="8%"  class="text-center">No.</th>
            <th width="15%" class="text-center">Faction ID</th>
            <th>Faction Name</th>
            <th width="12%" class="text-center">edit</th>
            <th width="12%" class="text-center">delete</th>
        </tr>
    </thead>

    <tbody>
        @foreach($faction as $row)
        <tr>
            {{-- running number across pagination --}}
            <td class="text-center">
                {{ ($faction->currentPage()-1)*$faction->perPage() + $loop->iteration }}
            </td>

            <td class="text-center">{{ $row->faction_id }}</td>
            <td>{{ $row->faction_name }}</td>

            <td class="text-center">
                <a href="{{ url('/faction/'.$row->faction_id) }}" class="btn btn-warning btn-sm">edit</a>
            </td>

            <td class="text-center">
                <button type="button" class="btn btn-danger btn-sm"
                        onclick="deleteConfirm({{ $row->faction_id }})">delete</button>

                <form id="delete-form-{{ $row->faction_id }}"
                      action="{{ url('/faction/remove/'.$row->faction_id) }}"
                      method="POST" style="display:none;">
                    @csrf
                    @method('delete')
                </form>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>

<div>
    {{ $faction->links() }}
</div>

@endsection

@section('footer')
@endsection

@section('js_before')
@endsection

@section('js_before')
@endsection




<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
function deleteConfirm(id) {
    Swal.fire({
        title: 'แน่ใจหรือไม่?',
        text: "คุณต้องการลบข้อมูลนี้จริง ๆ หรือไม่",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'ใช่, ลบเลย!',
        cancelButtonText: 'ยกเลิก'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('delete-form-' + id).submit();
        }
    })
}
</script>
