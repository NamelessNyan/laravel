-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2025 at 05:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel12`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_counter`
--

CREATE TABLE `tbl_counter` (
  `id` int(11) NOT NULL,
  `c_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_faction`
--

CREATE TABLE `tbl_faction` (
  `faction_id` int(11) NOT NULL,
  `faction_name` varchar(200) NOT NULL,
  `dateCreate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_faction`
--

INSERT INTO `tbl_faction` (`faction_id`, `faction_name`, `dateCreate`) VALUES
(3, '111', '2025-09-25 16:22:33'),
(4, '222', '2025-09-26 03:34:28');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gundam`
--

CREATE TABLE `tbl_gundam` (
  `gundam_id` int(11) NOT NULL,
  `gundam_name` varchar(200) NOT NULL,
  `gundam_model_no` varchar(100) NOT NULL,
  `faction_id` int(11) DEFAULT NULL,
  `series_id` int(11) DEFAULT 1,
  `height_m` decimal(5,2) DEFAULT NULL,
  `weight_kg` decimal(5,2) DEFAULT NULL,
  `gundam_image_url` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `dateCreate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_gundam`
--

INSERT INTO `tbl_gundam` (`gundam_id`, `gundam_name`, `gundam_model_no`, `faction_id`, `series_id`, `height_m`, `weight_kg`, `gundam_image_url`, `description`, `dateCreate`) VALUES
(10, 'dgdasd', '1111111111', 3, 3, 11.00, 11.00, 'uploads/gundam/xR51iYBG9GYIHGKwPRzNdjbjl1Y6aCQcM82o2B9p.jpg', '111', '2025-09-25 17:59:11');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_series`
--

CREATE TABLE `tbl_series` (
  `series_id` int(11) NOT NULL,
  `series_name` varchar(200) NOT NULL,
  `year` int(11) DEFAULT NULL,
  `dateCreate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_series`
--

INSERT INTO `tbl_series` (`series_id`, `series_name`, `year`, `dateCreate`) VALUES
(3, 'fgdg', 2100, '2025-09-25 16:14:54'),
(4, '222', 2100, '2025-09-26 03:34:41');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_staff`
--

CREATE TABLE `tbl_staff` (
  `staff_id` int(11) NOT NULL,
  `staff_name` varchar(200) NOT NULL,
  `staff_username` varchar(200) NOT NULL,
  `staff_password` varchar(255) NOT NULL,
  `email` varchar(200) DEFAULT NULL,
  `dateCreate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_staff`
--

INSERT INTO `tbl_staff` (`staff_id`, `staff_name`, `staff_username`, `staff_password`, `email`, `dateCreate`) VALUES
(2, '222', '2@2', '$2y$12$4q1p53sIrRWiq3JUmUEu2u25RcCtCDty1pvFKmHMovutGmL/2uvVW', NULL, '2025-09-25 13:54:56'),
(3, '111', '1@1', '$2y$12$Gf41n3MA.0d2LWJlnOAflO5AvY/p4BkLtEYaReXXUqKwSuxZeXMw2', NULL, '2025-09-25 16:21:49');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_test`
--

CREATE TABLE `tbl_test` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_test`
--

INSERT INTO `tbl_test` (`id`, `name`, `email`, `phone`) VALUES
(1, '222', '22@fdfdf', '2223434343'),
(2, '111', 'ss@g.com', '1111232324');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_counter`
--
ALTER TABLE `tbl_counter`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_c_date` (`c_date`),
  ADD KEY `idx_path_date` (`c_date`);

--
-- Indexes for table `tbl_faction`
--
ALTER TABLE `tbl_faction`
  ADD PRIMARY KEY (`faction_id`);

--
-- Indexes for table `tbl_gundam`
--
ALTER TABLE `tbl_gundam`
  ADD PRIMARY KEY (`gundam_id`),
  ADD KEY `fk_faction` (`faction_id`),
  ADD KEY `fk_series` (`series_id`);

--
-- Indexes for table `tbl_series`
--
ALTER TABLE `tbl_series`
  ADD PRIMARY KEY (`series_id`);

--
-- Indexes for table `tbl_staff`
--
ALTER TABLE `tbl_staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_counter`
--
ALTER TABLE `tbl_counter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_faction`
--
ALTER TABLE `tbl_faction`
  MODIFY `faction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_gundam`
--
ALTER TABLE `tbl_gundam`
  MODIFY `gundam_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_series`
--
ALTER TABLE `tbl_series`
  MODIFY `series_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_staff`
--
ALTER TABLE `tbl_staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_gundam`
--
ALTER TABLE `tbl_gundam`
  ADD CONSTRAINT `fk_faction` FOREIGN KEY (`faction_id`) REFERENCES `tbl_faction` (`faction_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_series` FOREIGN KEY (`series_id`) REFERENCES `tbl_series` (`series_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
